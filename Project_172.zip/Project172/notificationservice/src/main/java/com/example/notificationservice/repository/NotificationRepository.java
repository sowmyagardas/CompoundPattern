package main.java.com.example.notificationservice.repository;

public interface NotificationRepository extends JpaRepository<Notification, Long> {}