package main.java.com.example.notificationservice.controller;

public class NotificationController {
    
}
