package main.java.com.example.transactionservice.repository;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {
}