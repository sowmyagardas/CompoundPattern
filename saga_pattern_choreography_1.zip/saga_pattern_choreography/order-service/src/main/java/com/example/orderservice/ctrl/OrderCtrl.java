package com.example.orderservice.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.orderservice.entity.OrderDetails;
import com.example.orderservice.repository.OrderRepository;
import com.example.orderservice.service.OrderService;

@RestController
@RequestMapping("/order")
public class OrderCtrl {
	@Autowired
    private OrderService orderService;
	@Autowired
	private OrderRepository orderRepo;
	 
	@GetMapping	
	public List<OrderDetails> getAllOrder() {
		return orderRepo.findAll();
	}
	
	@PostMapping	 
    public ResponseEntity<OrderDetails> saveOrderQueue(@RequestBody OrderDetails order) {
        return ResponseEntity.ok(orderService.placeOrder(order));
    }

}
