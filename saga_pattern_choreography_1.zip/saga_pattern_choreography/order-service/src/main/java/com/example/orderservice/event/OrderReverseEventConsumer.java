package com.example.orderservice.event;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.example.orderservice.entity.OrderDetails;
import com.example.orderservice.repository.OrderRepository;

@Component
public class OrderReverseEventConsumer {
    @Autowired
    OrderRepository orderRepo;

    @KafkaListener(topics = "reverseOrder", groupId = "myGroup2")
    public void reverseOrder(OrderDetails order) {
         
        	// reverse status to failure
        	orderRepo.save(order);
        
        
        System.out.println("Received Message in group update Order : " + order);
    }
}
