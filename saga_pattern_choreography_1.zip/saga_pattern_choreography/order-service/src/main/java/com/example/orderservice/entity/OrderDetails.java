package com.example.orderservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class OrderDetails {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
		private Long productId;
		private Long userId;
	 	private Double orderAmount;
	 	private Status orderStatus;
		enum Status{
			PLACED,
			PAID,
			FAILED
		}
		public Status getOrderStatus() {
			return orderStatus;
		}
		public void setOrderStatus(String orderStatus) {
			this.orderStatus = Status.valueOf(orderStatus);;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Long getproductId() {
			return this.productId;
		}
		public void setProductId(Long pid) {
			this.productId = pid;
		}
		public Long getUserId() {
			return userId;
		}
		public void setUserId(Long uid) {
			this.userId = uid;
		}
		public Double getOrderAmount() {
			return orderAmount;
		}
		public void setOrderAmount(Double orderAmount) {
			this.orderAmount = orderAmount;
		}		 

}
