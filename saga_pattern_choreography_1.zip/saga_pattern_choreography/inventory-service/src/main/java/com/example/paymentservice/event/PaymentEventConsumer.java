package com.example.paymentservice.event;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import com.example.paymentservice.entity.OrderDetails;
import com.example.paymentservice.entity.Payment;
import com.example.paymentservice.repository.PaymentRepository;

@Component
public class PaymentEventConsumer {
    @Autowired
    PaymentRepository paymentRepo;
    @Autowired
    private KafkaTemplate<String, OrderDetails> kafkaTemplate;

    @KafkaListener(topics = "makePayment", groupId = "myGroup")
    public void createPayment(Payment payment) {
        try {
        	//simulate exception
        	if(payment.getAmount()>1000) {
				payment.setStatus("FAILED");
        		paymentRepo.save(payment);
        		throw new Exception();
        	}
        	payment.setStatus("COMPLETED");
    	paymentRepo.save(payment);
    	
        }catch(Exception e) {
        	OrderDetails order=new OrderDetails();
        	order.setId(payment.getOrderId());
        	order.setOrderStatus("FAILED");
			kafkaTemplate.send("reverseOrder", order);
        }
        
        System.out.println("Received Message in group create payment : " + payment);
    }
}
