package com.example.paymentservice.event;

public @interface GetMapping {

}
