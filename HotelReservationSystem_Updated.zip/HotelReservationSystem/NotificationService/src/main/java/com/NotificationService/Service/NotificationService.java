package com.NotificationService.Service;

import com.NotificationService.Repository.NotificationRepository;

import javax.management.Notification;

public class NotificationService {
    public NotificationRepository notificationRepository;
    
    public Notification saveNotification(Notification notify){
        return notificationRepository.save(notify);
    }
}
