package com.NotificationService.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Notification {
        @Id
        private Long id;
        private String message;
        private Long customerId;

        public Notification(Object object, Notification welcomeNotification, int i) {
        }
        public Long getNotificationId(){
                return id;
        }
        public String getNotificationMessage(){
                return message;
        }
        public Long getCustomerId(){
                return customerId;
        }
        public void setNotificationId(Long id){
                this.id = id;
        }
        public void setNotificationMessage(String msg){
                this.message = msg;
        }
        public void setCustomerId(Long cid){
                this.customerId = cid;
        }

}
