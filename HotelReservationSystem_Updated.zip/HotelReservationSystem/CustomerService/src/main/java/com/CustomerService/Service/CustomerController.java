package com.CustomerService.Service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    private RestTemplate restTemplate;
    private CustomerRepository customerRepository;
    private CustomerService customerService;

    @PostMapping
    public ResponseEntity<?> saveCustomer(@RequestBody Customer customer) {
        return ResponseEntity.ok(customerService.saveCustomer(customer));
    }

    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id) {
        return customerRepository.findById(id).orElse(null);
    }

    @GetMapping
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    @PostMapping("/userSignUp")
    public ResponseEntity<String> signUpUser(Customer signUpRequest)
    {
        String name = signUpRequest.getCustomerName();
        String email = signUpRequest.getCustomerEmail();
        if( name == null || email == null)
        {
            return ResponseEntity.badRequest().body("Name and email are required fields");
        }
        
        Customer newCustomer = new Customer();
        newCustomer.setCustomerName(signUpRequest.getCustomerName());
        newCustomer.setCustomerEmail(signUpRequest.getCustomerEmail());
       
        customerService.saveCustomer(newCustomer);
                
        String notificationServiceURL = "http://localhost:8085/notification/sendNotification";
        String response = restTemplate.getForObject(notificationServiceURL, String.class);
        
        System.out.println("Customer: Message sent to Notification. Response from notification: "+ response);

        return ResponseEntity.ok("User signed up successfully!");
    }
}
