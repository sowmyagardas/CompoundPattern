package com.CustomerService.Service;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String password;

    public Customer(String name, String email, String password){
        this.name = name;
        this.email = email;
        this.password = password;
    }
    public Customer() {
    }
    public Long getCustomerId(){
        return id;
    }
    
    public String getCustomerName(){
        return name;
    }

    public String getCustomerEmail(){
        return email;
    }

    public String getCustomerPassword(){
        return password;
    }

    public void setCustomerId(Long id){
        this.id = id;
    }

    public void setCustomerName(String name){
        this.name = name;
    }

    public void setCustomerEmail(String email){
        this.email = email;
    }

    public void setCustomerPassword(String password){
        this.password = password;
    }
}
