package com.CustomerService.Service;

import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    public CustomerRepository customerRepository;

    public Object saveCustomer(Customer customer){
        System.out.println("Inside save");
        customerRepository.save(customer);
        return null;
    }

    public Optional<Customer> getCustomerById(Long id){
        return customerRepository.findById(id);
    }

    public void deleteCustomer(Long id){
        customerRepository.deletById(id);
    }
}
