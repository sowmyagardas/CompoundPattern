package com.ReservationService.Entity;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "reservations")
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "customerId", nullable = false)
    private Long customerId;

    @Column(name = "hotelId", nullable = false)
    private Long hotelId;

    @Column(name = "startDate", nullable = false)
    private LocalDate startDate;

    @Column(name = "endDate", nullable = false)
    private LocalDate endDate;

    public Long getReservationId(){
        return id;
    }

    public Long getCustomerId(){
        return customerId;
    }

    public Long getHotelId(){
        return hotelId;
    }

    public LocalDate getStartDate(){
        return startDate;
    }

    public LocalDate getEndDate(){
        return endDate;
    }
    
    public void setReservationId(Long id){
        this.id = id;
    }

    public void setCustomerId(Long cid){
        this.customerId = cid;
    }

    public void setHotelId(Long hid){
        this.hotelId = hid;
    }

    public void setStartDate(LocalDate sdate){
        this.startDate = sdate;
    }

    public void setEndDate(LocalDate edate){
        this.endDate = edate;
    }

}
