package com.example.accountservice.service;

import java.util.Optional;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.accountservice.entity.Account;
import com.example.accountservice.repository.AccountRepository;

@Service
public class AccountService {
	@Autowired
	private AccountRepository bookRep;
	public boolean checkAvailability(Account bookOrder) {
	Optional<Account> book=	bookRep.findById(bookOrder.getId());
	if(book.isPresent()&&book.get().getQuantity()>bookOrder.getQuantity()) {
		Logger.getAnonymousLogger().info("Available success"+book.get().getTitle() +" " +book.get().getQuantity());
		return true;
	}
	Logger.getAnonymousLogger().info("Book unavailable"+bookOrder.getId() +" " +book.get().getQuantity());
	return false;	
		
	}
	
	public boolean updateInventory(Account bookOrder) {
		Optional<Account> book=	bookRep.findById(bookOrder.getId());
		if(book.isPresent()&&book.get().getQuantity()>bookOrder.getQuantity()) {
			book.get().setQuantity(book.get().getQuantity()-bookOrder.getQuantity());
			bookRep.save(book.get());
			Logger.getAnonymousLogger().info("Update Success: New Inventory"+book.get().getQuantity());
			return true;
		}
		Logger.getAnonymousLogger().info("Update Failed: Either item not found or insufficient count"+book.get().getQuantity());
		return false;	
			
		}

}
