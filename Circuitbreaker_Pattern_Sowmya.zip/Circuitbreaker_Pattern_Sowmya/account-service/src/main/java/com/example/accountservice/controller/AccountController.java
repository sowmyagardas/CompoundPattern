package com.example.accountservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.accountservice.entity.Account;
import com.example.accountservice.repository.AccountRepository;
import com.example.accountservice.service.AccountService;

@RestController
@RequestMapping("/book")
public class AccountController {
	@Autowired
    private AccountService bookService;
	@Autowired
	private AccountRepository bookRep;
	
	@PostMapping
	public Account create(@RequestBody Account book) {
		return bookRep.save(book);
	}
	@GetMapping	
	public List<Account> getAllBooks() {
		return bookRep.findAll();
	}
	
	@GetMapping(value = "/books/{id}")
	public Optional<Account> checkBookById(@PathVariable Long id) {
		return bookRep.findById(Long.valueOf(id));
	}
	
	 
	
	@PostMapping
	@RequestMapping("/checkAvailable")
	public boolean checkAvailability(@RequestBody Account book) {
		return bookService.checkAvailability(book);
	}
	
	@PostMapping
	@RequestMapping("/updateInventory")
	public boolean updateInventory(@RequestBody Account book) {
		System.out.println("Updating Inventory");
		return bookService.updateInventory(book);
	}


}
