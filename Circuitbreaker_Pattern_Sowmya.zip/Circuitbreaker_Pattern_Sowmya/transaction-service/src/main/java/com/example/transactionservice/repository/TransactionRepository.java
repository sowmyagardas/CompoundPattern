package com.example.orderservice.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.orderservice.entity.OrderDetails;

public interface TransactionRepository extends JpaRepository<OrderDetails, Long> {}
