package com.example.orderservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.orderservice.entity.OrderDetails;
import com.example.orderservice.repository.TransactionRepository;
import com.example.orderservice.service.OrderService;

@RestController
@RequestMapping("/order")
public class TransactionController {
	@Autowired
    private OrderService orderService;
	@Autowired
	private TransactionRepository orderRepo;
	@PostMapping
	public OrderDetails create(@RequestBody OrderDetails order) {
		System.out.println("Create book order"+order.getBookId());
		return orderService.placeOrder(order);
	}
	@GetMapping	
	public List<OrderDetails> getAllOrder() {
		return orderRepo.findAll();
	}

}
