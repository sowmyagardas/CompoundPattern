package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Demo;
import com.example.demo.DemoRepository;
import com.example.demo.DemoService;

@RestController
@RequestMapping("/demo")
public class DemoController {
    @Autowired
    private DemoService demoService;
    @Autowired
    private DemoRepository demoRepo;
	
	@PostMapping
	public ResponseEntity<?> saveDemo(@RequestBody Demo demo) {
        return ResponseEntity.ok(demoService.saveDemo(demo));
    }

    @GetMapping
    public List<Demo> getAllDemo() {
		return demoRepo.findAll();
	}
	
}
