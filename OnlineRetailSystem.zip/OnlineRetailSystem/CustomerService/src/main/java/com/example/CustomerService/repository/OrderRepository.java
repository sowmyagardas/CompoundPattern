package com.example.CustomerService.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.CustomerService.entity.OrderDetails;

public interface OrderRepository extends JpaRepository<OrderDetails, Long> {
	
	@Query(
			  value = "SELECT * FROM OrderDetails u WHERE u.customerId = :#{#orderdet.customerId}", 
			  nativeQuery = true)
			List<OrderDetails> findAllActiveUsersNative(@Param("orderdet") OrderDetails orderdet);
	
	 
}
