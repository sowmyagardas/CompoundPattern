package com.example.CustomerService.event;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.example.CustomerService.entity.OrderDetails;
import com.example.CustomerService.repository.OrderRepository;

@Component
public class OrderEventConsumer {
    @Autowired
    OrderRepository orderRepo;

    @KafkaListener(topics = "createOrderReport", groupId = "myGroup3")
    public void reverseOrder(OrderDetails order) {
         
        	// reverse status to failure
        	orderRepo.save(order);
        
        
        System.out.println("Received Message in group update / create Order Report: " + order);
    }
}
