package com.example.CustomerService.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.CustomerService.entity.OrderDetails;
import com.example.CustomerService.repository.OrderRepository;

@RestController
@RequestMapping("/CustomerServiceorder")
public class CustomerServiceController {
	
	@Autowired
	private OrderRepository orderRepo;
	 
	@GetMapping	
	public List<OrderDetails> getAllOrder() {
		return orderRepo.findAll();
	}
	
	@GetMapping	
	@RequestMapping("/{id}")
	public Optional<OrderDetails> getAllOrder(@PathVariable Long id) {
		return orderRepo.findById(id);
	}
	
	
 
}
