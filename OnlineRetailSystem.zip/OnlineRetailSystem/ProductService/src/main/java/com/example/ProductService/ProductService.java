package com.example.ProductService;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//Event listener interface
interface ProductEventListener{
    void onProductCreated(Product product);
    void onProductUpdated(Product product);
}
public class ProductService {
    private Map<Integer, Product> products;
    private List<ProductEventListener> listeners;

    public ProductService(){
        this.products = new HashMap<>();
        this.listeners = new ArrayList<>();
    }
    public void addEventListener(ProductEventListener listener){
        listeners.add(listener);
    }
    public void createProduct(int productId, String name, Double price){
        if(products.containsKey(productId)){
            throw new IllegalArgumentException("Product with same ID already exists.");
        }
        Product newProduct = new Product(productId,name,price);
        products.put(productId,newProduct);

        //Notify listener
        for(ProductEventListener listener : listeners){
            listener.onProductCreated(newProduct);
        }
        System.out.println("Product created successfully:" + newProduct);
    }
    public void updateProduct(int productId, String name, Double price){
        if(!products.containsKey(productId)){
            throw new IllegalArgumentException("Product does not exist.");
        }
        Product product = products.get(productId);
        if(name != null){
            product.setName(name);
        }
        if(price > 0){
            product.setPrice(price);
        }
        for(ProductEventListener listener : listeners){
            listener.onProductUpdated(product);
        }
        System.out.println("Product updated successfully:" + product);
    }
}
