package com.example.ProductService;

public class Product {
    private int productId;
    private String name;
    private Double price;

    public Product(int productId, String name, Double price){
        this.productId = productId;
        this.name = name;
        this.price = price;
    }    
    public void setName(String name){
        this.name = name;
    }
    public void setPrice(Double price){
        this.price = price;
    }
    @Override
    public String toString(){
        return "Product [ID=" + productId + ", Name=" + name + ", price=" + price +"]";
    }
}
