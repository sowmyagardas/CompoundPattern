package com.example.ProductService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductServiceApplication {

	public static void main(String[] args) {
		ProductService productService = new ProductService();
		productService.createProduct(1,"Laptop",1000.00);
		productService.updateProduct(1,"Gaming Laptop",1200.00);
		SpringApplication.run(ProductServiceApplication.class, args);
	}

}
