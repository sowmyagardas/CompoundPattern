package com.example.reportservice.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.reportservice.entity.Product;

public interface ProductReportRepository extends JpaRepository<Product, Long> {}
