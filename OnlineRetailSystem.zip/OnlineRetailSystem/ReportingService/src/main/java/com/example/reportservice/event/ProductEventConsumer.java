package com.example.reportservice.event;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.example.reportservice.entity.Product;
import com.example.reportservice.repository.ProductReportRepository;

@Component
public class ProductEventConsumer {
    @Autowired
    ProductReportRepository orderRepo;

    @KafkaListener(topics = "createProductReport", groupId = "myGroup7")
    public void productReport(Product product) {
         
        	// reverse status to failure
        	orderRepo.save(product);
        
        
        System.out.println("Received Message in group update / create Product report : " + product);
    }
}
