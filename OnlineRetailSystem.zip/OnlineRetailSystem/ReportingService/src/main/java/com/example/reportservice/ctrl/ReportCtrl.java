package com.example.reportservice.ctrl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.reportqueryservice.EventReportService;
import com.example.reportservice.entity.EventDetails;
import com.example.reportservice.entity.Product;
import com.example.reportservice.repository.ProductReportRepository;

@RestController
@RequestMapping("/reportproduct")
public class ReportCtrl {
	
	@Autowired
	private ProductReportRepository productRepo;
	
	@Autowired
	private EventReportService eventReport;
	 
	@GetMapping	
	public List<Product> getAllOrder() {
		return productRepo.findAll();
	}
	
	@GetMapping	
	@RequestMapping("/{id}")
	public Optional<Product> getAllProductReport(@PathVariable Long id) {
		return productRepo.findById(id);
	}
	
	@GetMapping	
	@RequestMapping("/getreportEvent")
	public List<EventDetails> getAllEvents() {
		return eventReport.reportEvent();
	}
	
	
 
}
