package com.example.reportqueryservice;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.reportservice.entity.EventDetails;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class EventReportService {
	

	 @CircuitBreaker(name = "reportevent-service", fallbackMethod = "getDefaultEvent")
	public List<EventDetails> reportEvent() {
		
		RestTemplate restTemplate=new RestTemplate();
		  HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_JSON);
		 HttpEntity<EventDetails> entity = new HttpEntity<>(null, headers);
		 ResponseEntity<List> response = restTemplate.exchange(
	                ("http://localhost:8085/eventdetails" ),
	                HttpMethod.GET, entity,
	                List.class);
		
		List<EventDetails> eventDet=response.getBody();
		 
		return eventDet;
		
	}
	
		
	public List<EventDetails> getDefaultEvent(Throwable e){
			System.out.println("Inside fallback");
			 return new ArrayList <EventDetails>();
			
		}

}
