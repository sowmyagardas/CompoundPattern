package com.example.OrderService;

import java.util.Map;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class OrderDetails {
    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long orderId;
	    private String name;
	    
        public OrderDetails(int orderId2, customer customer, Map<Product, Integer> orderProducts) {
		}
		public Long orderId() {
			return orderId;
		}
		public void setOrderId(Long id) {
			this.orderId = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
}
