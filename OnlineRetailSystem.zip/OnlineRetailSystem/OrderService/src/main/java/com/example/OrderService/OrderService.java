package com.example.OrderService;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;

import com.example.ProductService.ProductService;

public class OrderService {
    private Map<Integer, Order> orders;
    private ProductService productService;
    @Autowired
    private KafkaTemplate<String, Order> kafkaTemplate;
	
	@Autowired
	private OrderRepository orderRepo;
		
		 public Order saveOrder(Order order){
			 Order savedOrder = orderRepo.save(order);
			 kafkaTemplate.send("createOrder", order);
		        return savedOrder;
		    }


    public OrderService(ProductService productService){
        this.orders = new HashMap<>();
        this.productService = productService;
    }

    public void createOrderCommand(int orderId, int customerId, Map<Integer, Integer) products){
        Customer customer = getCustomerById(customerId);
        if(customer == null){
            throw new IllegalArgumentException("Customer not found");
        }
        Map<Product, Integer> orderProducts = new HashMap<>();
        for (Map.Entry<Integer, Integer> entry : products.entySet()){
            int productId = entry.getKey();
            int quantity = entry.getValue();
            Product product = productService.getProductById(productId);
            if(product == null){
                throw new IllegalArgumentException("Product not found");
            }
            orderProducts.put(product,quantity);
        }

        Order newOrder = new Order(orderId, customer, orderProducts);
        orders.put(orderId,newOrder);

        System.out.println("Order created successfully:" + newOrder);

    }
    private Customer getCUstomerById(int customerId){
        return new Customer(customerId, "John", "john@gmail.com");
    }
}
