package com.example.OrderService;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;

public class OrderService {
    private Map<Integer, OrderDetails> orders;

    @Autowired
    private KafkaTemplate<String, OrderDetails> kafkaTemplate;
	
	@Autowired
	private OrderRepository orderRepo;
		
		 public OrderDetails saveOrder(OrderDetails order){
			 OrderDetails savedOrder = orderRepo.save(order);
			 kafkaTemplate.send("createOrder", order);
		        return savedOrder;
		    }


    public void createOrderCommand(int orderId, int customerId, Map<Integer, Integer> products){
        customer customer = getCustomerById(customerId);
        if(customer == null){
            throw new IllegalArgumentException("Customer not found");
        }
        Map<Product, Integer> orderProducts = new HashMap<>();
        for (Map.Entry<Integer, Integer> entry : products.entrySet()){
            int productId = entry.getKey();
            int quantity = entry.getValue();
            Product product = getProductById(productId);
            if(product == null){
                throw new IllegalArgumentException("Product not found");
            }
            orderProducts.put(product,quantity);
        }

        OrderDetails newOrder = new OrderDetails(orderId, customer, orderProducts);
        orders.put(orderId,newOrder);

        System.out.println("Order created successfully:" + newOrder);

    }
    private Product getProductById(int productId) {
        return null;
    }


    private customer getCustomerById(int customerId){
        return new customer(customerId, "John", "john@gmail.com");
    }
}
