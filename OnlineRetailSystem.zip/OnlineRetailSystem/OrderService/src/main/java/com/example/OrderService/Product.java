package com.example.OrderService;

public class Product {
    private int productId;
    private String name;
    private Double price;

    public Product(int productId, String name, Double price){
        this.productId = productId;
        this.name = name;
        this.price = price;
    }    
    public Product getProductById(int pid){
        Product prod = new Product(1,"colgate",50.00);
        return prod;
    }
    public int getProductId(){
        return productId;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setPrice(Double price){
        this.price = price;
    }
    @Override
    public String toString(){
        return "Product [ID=" + productId + ", Name=" + name + ", price=" + price +"]";
    }
}

