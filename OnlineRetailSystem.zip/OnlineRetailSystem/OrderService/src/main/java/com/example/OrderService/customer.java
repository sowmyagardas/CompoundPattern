package com.example.OrderService;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class customer {
    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long customerId;
	    private String name;
	    private String mailId;

        public Long getCustomerId() {
			return customerId;
		}
		public void setCustomerId(Long id) {
			this.customerId = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
        public String getMailId() {
			return mailId;
		}
		public void setMailId(String mailId) {
			this.mailId = mailId;
        }
        public customer getCustomerById(Long id){
            customer cus = new customer();
            return cus;
        }
}
