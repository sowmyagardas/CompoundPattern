package com.example.eventservice.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.eventservice.entity.EventDetails;
import com.example.eventservice.repository.EventRepository;

@RestController
@RequestMapping("/eventdetails")
public class EventCtrl {
	
	@Autowired
	private EventRepository orderRepo;
	 
	@GetMapping	
	public List<EventDetails> getAllOrder() {
		return orderRepo.findAll();
	}
	
	@GetMapping	
	@RequestMapping("/{id}")
	public Optional<EventDetails> getAllOrder(@PathVariable Long id) {
		return orderRepo.findById(id);
	}
	
	
 
}
