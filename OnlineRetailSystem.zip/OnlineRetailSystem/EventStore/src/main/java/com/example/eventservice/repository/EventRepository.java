package com.example.eventservice.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.eventservice.entity.EventDetails;

public interface EventRepository extends JpaRepository<EventDetails, Long> {}
