package com.example.eventservice.event;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.example.eventservice.entity.EventDetails;
import com.example.eventservice.repository.EventRepository;

@Component
public class EventSourceConsumer {
    @Autowired
    EventRepository eventRepo;

    @KafkaListener(topics = "createEvent", groupId = "myGroup")
    public void reverseOrder(EventDetails event) {
         
        	// reverse status to failure
    	eventRepo.save(event);
        
        
        System.out.println("Received Message in group update / create event : " + event);
    }
}
