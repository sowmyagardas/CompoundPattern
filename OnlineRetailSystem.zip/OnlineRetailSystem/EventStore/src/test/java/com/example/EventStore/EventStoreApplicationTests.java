package com.example.EventStore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventStoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
