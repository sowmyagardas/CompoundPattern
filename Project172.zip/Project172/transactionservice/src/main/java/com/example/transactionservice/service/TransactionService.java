package main.java.com.example.transactionservice.service;

public class TransactionService {
    @PostMapping("/initiate")
public Transaction initiateTransaction(@RequestBody Transaction transaction) {
    transaction.setStatus(Status.PENDING);
    transactionRepository.save(transaction);
    eventPublisher.publishStartTransactionEvent(new StartTransactionEvent(transaction.getId()));
    return transaction;
}

@Async("taskExecutor")
public void processTransaction(Transaction transaction) {
    Account acc=new Account();
		acc.setId(transaction.getId());		
		RestTemplate restTemplate=new RestTemplate();
		  HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_JSON);
		 HttpEntity<Account> entity = new HttpEntity<>(null, headers);
		 ResponseEntity<Account> response = restTemplate.exchange(
	                ("http://localhost:8081/account/accounts/" + account.getId()),
	                HttpMethod.GET, entity,
	                Account.class);
		
		Account accountResp=response.getBody();
		if(accountResp!=null) {
			transaction.setStatus(SUCCESS);
			transaction=transactionRepo.save(transaction);			
		}else {
			transaction.setStatus(FAILED);
			transaction=transactionRepo.save(order);
			 System.out.println("Transaction failed");
			 
		}
		System.out.println("Return");
		return transaction;
	}

}
public class TransactionLoggingProxy {
    
    private final TransactionService transactionService;
    
    public TransactionLoggingProxy(TransactionService transactionService) {
        this.transactionService = transactionService;
    }
    
    public Transaction initiateTransaction(Long senderId, Long receiverId, Double amount) {
        log.info("Transaction Initiated: SenderId=" + senderId + ", ReceiverId=" + receiverId + ", Amount=" + amount);
        Transaction transaction = transactionService.initiateTransaction(senderId, receiverId, amount);
        log.info("Transaction Status: " + transaction.getStatus());
        return transaction;
    }
}
