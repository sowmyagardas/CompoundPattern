package main.java.com.example.transactionservice.service;

public class TransactionService {
    @PostMapping("/initiate")
public Transaction initiateTransaction(@RequestBody Transaction transaction) {
    transaction.setStatus(Status.PENDING);
    transactionRepository.save(transaction);
    eventPublisher.publishStartTransactionEvent(new StartTransactionEvent(transaction.getId()));
    return transaction;
}
}
