package main.java.com.example.transactionservice.entity;

@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long senderId;
    private Long receiverId;
    private Double amount;
    private Status status;  // Enum: PENDING, SUCCESS, FAILURE
    // Getters and Setters
}
