package main.java.com.example.transactionservice.entity;

@Entity
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long senderId;
    private Long receiverId;
    private Double amount;
    private Status status;  // Enum: PENDING, SUCCESS, FAILURE
    private enum Status{
        PENDING,
        SUCCESS,
        FAILURE
    }
    // Getters and Setters
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getSenderId() {
        return senderId;
    }
    public void setSenderId(Long id) {
        this.senderId = id;
    }
    public Long getReceiverId() {
        return receiverId;
    }
    public void setReceiverId(Long id) {
        this.receiverId = id;
    }
    public Double getAmount() {
        return amount;
    }
    public void setAmount(Double amt) {
        this.amount = amt;
    }
    public Status getStatus(){
        return status;
    }
    public void setStatus(Status status){
        this.status = status;
    }
}
