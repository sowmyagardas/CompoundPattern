package main.java.com.example.notificationservice.entity;

public class Notification {
    private Long userId;
    private String message;
    // Getters and Setters
    public Long getId() {
        return userId;
    }
    public void setId(Long id) {
        this.useId = id;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String msg) {
        this.message = msg;
    }
}
