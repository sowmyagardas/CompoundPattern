package main.java.com.example.notificationservice.entity;

public class Notification {
    private Long userId;
    private String message;
    // Getters and Setters
}
