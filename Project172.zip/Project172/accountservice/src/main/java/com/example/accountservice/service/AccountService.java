package com.example.accountservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.accountservice.entity.Account;
import com.example.accountservice.repository.AccountRepository;

public class AccountService {
    @Autowired
    private AccountRepository accountRepository;

    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }

    public Optional<Account> getAccount(Long id) {
        return accountRepository.findById(id);
    }

    public Account deposit(Long id, double amount) {
        Account account = getAccount(id).orElseThrow(() -> new RuntimeException("Account not found"));
        account.setBalance(account.getBalance() + amount);
        return accountRepository.save(account);
    }

    public Account withdraw(Long id, double amount) {
        Account account = getAccount(id).orElseThrow(() -> new RuntimeException("Account not found"));
        if (account.getBalance() < amount) {
            throw new RuntimeException("Insufficient funds");
        }
        account.setBalance(account.getBalance() - amount);
        return accountRepository.save(account);
    }

   
    @EventListener
    public void handleStartTransactionEvent(StartTransactionEvent event) {
    try {
        Transaction transaction = fetchTransactionDetails(event.getTransactionId());
        processTransaction(transaction);
        eventPublisher.publishTransactionSuccessEvent(new TransactionSuccessEvent(transaction.getId()));
    } catch (AccountException e) {
        eventPublisher.publishTransactionFailureEvent(new TransactionFailureEvent(event.getTransactionId(), e.getMessage()));
    }
}
}
