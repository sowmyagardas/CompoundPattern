package com.example.accountservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String accountHolderName;
    private double balance;

	public String getAccountHolderName() {
		return this.accountHolderName;
	}
    public void setAccountHolderName(String name) {
		this.accountHolderName = name;
    }

	public double getBalance() {
		return this.balance;
	}
    
    public void setBalance(double d) {
		this.balance = d;
    }
}
