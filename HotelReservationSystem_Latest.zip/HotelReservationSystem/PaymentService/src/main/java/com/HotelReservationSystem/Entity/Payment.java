package com.HotelReservationSystem.Entity;

import java.math.BigDecimal;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private BigDecimal amount;

    public Payment(Long id, Long customerId, BigDecimal amount){
        this.id = id;
        this.customerId = customerId;
        this.amount = amount;
    }

    public Payment(){

    }

    public Long getId(){
        return id;
    }

    public Long getCustomerId(){
        return customerId;
    }

    public BigDecimal getAmount(){
        return amount;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setCustomerId(Long cid){
        this.customerId = cid;
    }

    public void setAmount(BigDecimal amount){
        this.amount = amount;
    }
}
