package com.HotelReservationSystem.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private Double amount;

    public Long getId(){
        return id;
    }

    public Long getCustomerId(){
        return customerId;
    }

    public Double getAmount(){
        return amount;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setCustomerId(Long cid){
        this.customerId = cid;
    }

    public void setAmount(Double amount){
        this.amount = amount;
    }

    public Payment receivePayment(Payment payment) {
        return null;
    }
}
