package com.HotelReservationSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HotelReservationSystem.Entity.Reservation;
import com.HotelReservationSystem.Repository.ReservationRepository;
import com.HotelReservationSystem.ReservationService.ReservationService;

@RestController
@RequestMapping("/reservation")
public class ReservationController {
    @Autowired
    private ReservationService reservationService;
    @Autowired
    private ReservationRepository reservationRepo;
	
	@PostMapping
	public ResponseEntity<?> makeReservation(@RequestBody Reservation reservation) {
        return ResponseEntity.ok(reservationService.saveReservation(reservation));
    }

    @GetMapping("/{id}")
    public Reservation getReservationById(@PathVariable Long id) {
        return reservationRepo.findById(id).orElse(null);
    }

    @GetMapping
    public List<Reservation> getAllReservations() {
		return reservationRepo.findAll();
	}
}
