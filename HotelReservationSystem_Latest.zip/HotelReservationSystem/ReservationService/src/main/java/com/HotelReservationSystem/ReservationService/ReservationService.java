package com.HotelReservationSystem.ReservationService;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.HotelReservationSystem.Entity.Reservation;
import com.HotelReservationSystem.Model.Payment;
import com.HotelReservationSystem.Model.RoomInventory;
import com.HotelReservationSystem.Repository.ReservationRepository;

@Service
public class ReservationService {
    @Autowired
	private ReservationRepository reservationRepository;
    RoomInventory roomInventoryClient;
    Payment paymentClient;
    @Autowired
    private RestTemplate restTemplate;
    
    public ResponseEntity<?> saveReservation(Reservation reservation) {
        RoomInventory roomInventory = new RoomInventory();
        roomInventory.setId(reservation.getHotelId());
        Map<String, String> requestBody = new HashMap<>();
        ResponseEntity<RoomInventory> roomResponse = restTemplate.postForEntity("http://localhost:8083/hotelmanagement" + "/availability", requestBody, RoomInventory.class);
        
        if (roomResponse != null) {
            Payment newPayment = new Payment(1,1,1000.00);
            ResponseEntity<String> response = restTemplate.postForEntity("http://localhost:8084/payment" , String.class);
        
                //if(response.getBody() != null){
                  //  String responseStr = response.getBody();
                    //if(responseStr != null)
                   /* {
                        int begin = responseStr.indexOf("{");   
                        int end = responseStr.lastIndexOf("}") + 1;
                        responseStr = responseStr.substring(begin, end);*/
                        reservationRepository.save(reservation);
                        return ResponseEntity.ok("Room reserved!");
                    //}
                }
                else{
                    return ResponseEntity.ok("Reservation Failed!");
                }                             
        //    }
      //  }
    }

    public ResponseEntity<String> updateReservation(Reservation reservation) {
        Long reservationId = reservation.getId();
        if(! reservationRepository.existsById(reservationId)){
            throw new ReservationNotFoundException("Reservation not found with ID: "+ reservationId);
        }
        Reservation existingReservation = reservationRepository.findById(reservationId).orElse(null);
        if(existingReservation != null){
            existingReservation.setId(reservation.getId());
            existingReservation.setCustomerId(reservation.getCustomerId());
            existingReservation.setHotelId(reservation.getHotelId());
            existingReservation.setStartDate(reservation.getStartDate());
            existingReservation.setEndDate(reservation.getEndDate());
            }
        reservationRepository.save(existingReservation);
        return ResponseEntity.ok("Reservation updated successfully!");
    }

    public ResponseEntity<String> cancelReservation(Long reservationId) {
        if(! reservationRepository.existsById(reservationId)){
            throw new ReservationNotFoundException("Reservation not found with ID: "+ reservationId);
        }
        reservationRepository.deleteById(reservationId);
        return ResponseEntity.ok("Reservation cancelled successfully!");
    }

}
