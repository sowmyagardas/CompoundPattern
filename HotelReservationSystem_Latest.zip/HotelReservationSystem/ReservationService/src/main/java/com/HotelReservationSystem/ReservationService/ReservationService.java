package com.HotelReservationSystem.ReservationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.HotelReservationSystem.Entity.Reservation;
import com.HotelReservationSystem.Repository.ReservationRepository;

@Service
public class ReservationService {
    @Autowired
	private ReservationRepository reservationRepository;

    public ResponseEntity<?> saveReservation(Reservation reservation) {
        reservationRepository.save(reservation);
        return ResponseEntity.ok("Reservation successful!");
    }
}
