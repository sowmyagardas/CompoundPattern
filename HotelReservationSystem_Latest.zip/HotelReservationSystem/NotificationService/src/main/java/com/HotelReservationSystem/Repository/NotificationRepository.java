package com.HotelReservationSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.HotelReservationSystem.Entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    
}
