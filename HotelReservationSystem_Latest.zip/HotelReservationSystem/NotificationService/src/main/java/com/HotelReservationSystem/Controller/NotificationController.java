package com.HotelReservationSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HotelReservationSystem.Entity.Notification;
import com.HotelReservationSystem.NotificationService.NotificationService;
import com.HotelReservationSystem.Repository.NotificationRepository;

@RestController
@RequestMapping("/notification")
public class NotificationController {
    @Autowired
    private NotificationService notificationService;
    @Autowired
    private NotificationRepository notificationRepo;
	
	@PostMapping
	public ResponseEntity<?> saveNotification(@RequestBody Notification notification) {
        return ResponseEntity.ok(notificationService.saveNotification(notification));
    }

    @GetMapping
    public List<Notification> getAllNotifications() {
		return notificationRepo.findAll();
	}

    @GetMapping("/{id}")
    public Notification getNotificationById(@PathVariable Long id) {
        return notificationRepo.findById(id).orElse(null);
    }

    @PostMapping("/{notify}")
	public ResponseEntity<?> sendNotification(String message) {
        Notification newNotify = new Notification();
        newNotify.saveMessage(message);
        return ResponseEntity.ok(notificationService.saveNotification(newNotify));
    }


}
