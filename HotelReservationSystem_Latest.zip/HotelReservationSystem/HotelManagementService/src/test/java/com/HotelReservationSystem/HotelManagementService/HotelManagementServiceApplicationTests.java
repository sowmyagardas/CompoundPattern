package com.HotelReservationSystem.HotelManagementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
