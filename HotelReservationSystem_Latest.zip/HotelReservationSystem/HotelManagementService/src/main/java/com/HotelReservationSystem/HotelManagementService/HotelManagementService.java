package com.HotelReservationSystem.HotelManagementService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.HotelReservationSystem.Entity.HotelManagement;
import com.HotelReservationSystem.Repository.HotelManagementRepository;

@Service
public class HotelManagementService {
    @Autowired
	private HotelManagementRepository hotelRepository;

    public Object saveHotelManagement(HotelManagement hotelManagement) {
        System.out.println("HotelManagement details saved");
        hotelRepository.save(hotelManagement);
        return null;
    }
    
    public ResponseEntity<?> deleteRoom(Long hotelId){
        hotelRepository.deleteById(hotelId);
        return ResponseEntity.ok("Deleted Room! ");
    }
}
