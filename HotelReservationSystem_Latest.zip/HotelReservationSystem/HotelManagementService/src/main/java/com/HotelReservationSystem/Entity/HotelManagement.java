package com.HotelReservationSystem.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class HotelManagement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String location;
    private int numberOfRooms;

    public HotelManagement()
    {

    }

    public HotelManagement(Long id, String name, String location, int numberOfRooms){
        this.id = id;
        this.name = name;
        this.location = location;
        this.numberOfRooms = numberOfRooms;
    }
    public Long getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    public String getLocation(){
        return location;
    }

    public int getRooms(){
        return numberOfRooms;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setName(String name){
        this.name = name;
    }

    public void setLocation(String loc){
        this.location = loc;
    }

    public void setRooms(int count){
        this.numberOfRooms = count;
    }



}
