package com.HotelReservationSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HotelReservationSystem.Entity.RoomInventory;
import com.HotelReservationSystem.HotelManagementService.HotelManagementService;
import com.HotelReservationSystem.Repository.HotelManagementRepository;

@RestController
@RequestMapping("/hotelmanagement")
public class HotelManagementController {
    @Autowired
    private HotelManagementService hotelManagementService;
    @Autowired
    private HotelManagementRepository hotelManagementRepo;
	
	@PostMapping
	public ResponseEntity<?> bookARoomInAHotel(@RequestBody RoomInventory hotelManagement) {
        return ResponseEntity.ok(hotelManagementService.saveHotelManagement(hotelManagement));
    }

    @GetMapping("/{id}")
    public RoomInventory getHotelById(@PathVariable Long id) {
        return hotelManagementRepo.findById(id).orElse(null);
    }

    @GetMapping
    public List<RoomInventory> getAllRooms() {
		return hotelManagementRepo.findAll();
	}

    @PostMapping("/availability")
    public RoomInventory getAvailability(@RequestBody RoomInventory roomInventory){
        return hotelManagementService.getRoomInventoryAvailability(roomInventory);
    }
    @PutMapping("/update")
    public RoomInventory updateInventory(@RequestBody RoomInventory roomInventory){
        return hotelManagementService.updateRoomInventory(roomInventory);
    }
    @DeleteMapping("/{roomId}")
    public ResponseEntity<?> deleteRoom(@PathVariable Long roomId) {
        return ResponseEntity.ok(hotelManagementService.deleteRoom(roomId));
    }
   
}
