package com.HotelReservationSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HotelReservationSystem.Entity.HotelManagement;
import com.HotelReservationSystem.HotelManagementService.HotelManagementService;
import com.HotelReservationSystem.Repository.HotelManagementRepository;

@RestController
@RequestMapping("/hotelmanagement")
public class HotelManagementController {
    @Autowired
    private HotelManagementService hotelManagementService;
    @Autowired
    private HotelManagementRepository hotelManagementRepo;
	
	@PostMapping
	public ResponseEntity<?> createHotel(@RequestBody HotelManagement hotelManagement) {
        return ResponseEntity.ok(hotelManagementService.saveHotelManagement(hotelManagement));
    }

    @GetMapping("/{id}")
    public HotelManagement getHotelById(@PathVariable Long id) {
        return hotelManagementRepo.findById(id).orElse(null);
    }
   
}
