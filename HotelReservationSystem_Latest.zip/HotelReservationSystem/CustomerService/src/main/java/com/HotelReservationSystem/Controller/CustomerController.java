package com.HotelReservationSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HotelReservationSystem.CustomerService.CustomerService;
import com.HotelReservationSystem.Entity.Customer;
import com.HotelReservationSystem.Repository.CustomerRepository;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private CustomerRepository customerRepo;
    
    @PostMapping
    public ResponseEntity<?> saveCustomer(@RequestBody Customer customer) {
        return ResponseEntity.ok(customerService.saveCustomer(customer));
    }

	@PostMapping("/{signUp}")
	public ResponseEntity<?> signUpCustomer(@RequestBody Customer customer) {
        
        String name = customer.getName();
        String email = customer.getEmail();
        String password = customer.getPassword();
        if( name == null || email == null || password == null)
        {
            return ResponseEntity.badRequest().body("Name,email and password are required fields");
        }
        
        customerService.saveCustomer(customer);
        return ResponseEntity.ok("User signed up successfully!");
    }

    @GetMapping
    public List<Customer> getAllCustomers() {
		return customerRepo.findAll();
	}

    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id) {
        return customerRepo.findById(id).orElse(null);
    }

}
