package com.example.transactionservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Transaction {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id;
		private Long senderId;
		private Long receiverId;
		private Double amount;
		private Status status;  // Enum: PENDING, SUCCESS, FAILURE

		public enum Status {
			PENDING, SUCCESS, FAILURE
		}

		// Getters and Setters

}
