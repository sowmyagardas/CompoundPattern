package com.example.transactionservice.repository;

import javax.transaction.Transaction;

import org.springframework.data.jpa.repository.JpaRepository;


public interface TransactionRepository extends JpaRepository<Transaction , Long> {}
