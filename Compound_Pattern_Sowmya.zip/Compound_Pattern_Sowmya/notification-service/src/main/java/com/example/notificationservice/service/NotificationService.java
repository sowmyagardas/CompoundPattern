package com.example.notificationservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.notificationservice.entity.Notification;
import com.example.notificationservice.entity.OrderDetails;
import com.example.notificationservice.repository.NotificationRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class NotificationService {
	
	@Autowired
	private NotificationRepository orderRepo;
	 @CircuitBreaker(name = "order-service", fallbackMethod = "getDefaultBook")
	public OrderDetails placeOrder(OrderDetails order) {
		Notification book=new Notification();
		book.setId(order.getBookId());		
		RestTemplate restTemplate=new RestTemplate();
		  HttpHeaders headers = new HttpHeaders();
	        headers.setContentType(MediaType.APPLICATION_JSON);
		 HttpEntity<Notification> entity = new HttpEntity<>(null, headers);
		 ResponseEntity<Notification> response = restTemplate.exchange(
	                ("http://localhost:8081/book/books/" + order.getBookId()),
	                HttpMethod.GET, entity,
	                Notification.class);
		
		Notification bookResp=response.getBody();
		if(bookResp!=null) {
			order.setOrderStatus("Success");
			order=orderRepo.save(order);			
		}else {
			order.setOrderStatus("Failed");
			order=orderRepo.save(order);
			 System.out.println("Post fall back");
			 
		}
		System.out.println("Return");
		return order;
		
		
	}
	 
	 
		
		
		public  OrderDetails getDefaultBook(com.example.notificationservice.entity.OrderDetails order, Throwable e){
			System.out.println("Inside fallback");
			order.setOrderStatus("Failed");
			order=orderRepo.save(order);
			return order;
			
		}

}
