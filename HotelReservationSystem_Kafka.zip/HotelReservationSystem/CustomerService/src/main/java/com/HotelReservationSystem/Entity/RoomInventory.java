package com.HotelReservationSystem.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class RoomInventory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String roomType;
    private int quantity;
    private Double amount;
    private int totalQuantity;

    public RoomInventory()
    {

    }

    public RoomInventory(Long id, String roomType, int quantity, Double amount, int totalQuantity){
        this.id = id;
        this.roomType = roomType;
        this.quantity = quantity;
        this.amount = amount;
        this.totalQuantity = totalQuantity;
    }
    public Long getId(){
        return id;
    }

    public String getRoomType(){
        return roomType;
    }

    public int getQuantity(){
        return quantity;
    }

    public Double getAmount(){
        return amount;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setRoomType(String type){
        this.roomType = type;
    }

    public void setQuantity(int quan){
        this.quantity = quan;
    }

    public void setAmount(Double amt){
        this.amount = amt;
    }

    public int getTotalQuantity(){
        return totalQuantity;
    }

    public void setTotalQuantity(int quan){
        this.totalQuantity = quan;
    }
}
