package com.HotelReservationSystem.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.HotelReservationSystem.CustomerService.CustomerService;
import com.HotelReservationSystem.Entity.Customer;
import com.HotelReservationSystem.Repository.CustomerRepository;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private CustomerRepository customerRepo;
    @Autowired
    private RestTemplate restTemplate;
    
    @PostMapping
    public ResponseEntity<?> saveCustomer(@RequestBody Customer customer) {
        return ResponseEntity.ok(customerService.saveCustomer(customer));
    }

	@PostMapping("/{signUp}")
	public ResponseEntity<?> signUpCustomer(@RequestBody Customer customer) {
        
        String name = customer.getName();
        String email = customer.getEmail();
        String password = customer.getPassword();
        if( name == null || email == null || password == null)
        {
            return ResponseEntity.badRequest().body("Name,email and password are required fields");
        }
        
        customerService.saveCustomer(customer);

        Map<String, String> requestBody = new HashMap<>();
        requestBody.put("message", "Welcome, !Thank you for signing up" + customer.getName());

        ResponseEntity<String> response = restTemplate.postForEntity("http://localhost:8082/notification" + "/send", requestBody, String.class);

        if(response.getBody() != null){
            
            String responseStr = response.getBody();
            if(responseStr != null){
            int begin = responseStr.indexOf("{");   
            int end = responseStr.lastIndexOf("}") + 1;
            responseStr = responseStr.substring(begin, end);
            return ResponseEntity.ok("SignUp successful!\n" + responseStr);
            }
        }
        else{
            return ResponseEntity.ok("User signedUp Failed!");
        }
        return null;
    }
      
    @GetMapping
    public List<Customer> getAllCustomers() {
		return customerRepo.findAll();
	}

    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id) {
        return customerRepo.findById(id).orElse(null);
    }

}
