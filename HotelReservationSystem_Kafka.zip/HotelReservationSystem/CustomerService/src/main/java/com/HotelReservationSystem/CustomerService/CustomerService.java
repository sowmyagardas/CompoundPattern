package com.HotelReservationSystem.CustomerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.HotelReservationSystem.Entity.Customer;
import com.HotelReservationSystem.Repository.CustomerRepository;

@Service
public class CustomerService {
    @Autowired
	private CustomerRepository customerRepository;

    public Object saveCustomer(Customer customer) {
        System.out.println("Customer details saved");
        customerRepository.save(customer);
        return null;
    }
    
    public void deleteCustomer(Long id){
        customerRepository.deleteById(id);
    }
}

