package com.HotelReservationSystem.CustomerService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.HotelReservationSystem.Entity.Customer;
import com.HotelReservationSystem.Entity.Notification;
import com.HotelReservationSystem.Entity.RoomInventory;
import com.HotelReservationSystem.Repository.CustomerRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class CustomerService {
    @Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private KafkaTemplate<String, Notification> kafkaTemplate;
	private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);
	@Autowired
    	private RestTemplate restTemplate;
		

	public ResponseEntity<?> updateCustomer(Customer customer) {
		Optional<Customer> customerFound = customerRepository.findById(customer.getId());
		if (customerFound.isPresent()) {
			customerRepository.save(customer);		
			// Send event to notification service to send notification
			Notification notification = new Notification();
			notification.setMessage("Customer details updated successfully!");
			kafkaTemplate.send("sendNotification", notification);			
			return ResponseEntity.ok("Customer details updated!");
		}
		return ResponseEntity.ok("Customer not found");
	}

	@CircuitBreaker(name = "HotelManagementService", fallbackMethod = "getDefaultHotelListing")
	public List<RoomInventory> getHotelListing(Boolean simulateFallback) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders(null);
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List> entity = new HttpEntity<>(null, headers);
		ResponseEntity<List> response =null;
		// Rest Template implementation
		// Actual service runs in 8083 port. To simulate circuit breaker 8085 port
		// applied so that fallback method gets called
		if(simulateFallback) {
		 System.out.println("Inside simulate Fallback");
		 response = restTemplate.exchange(("http://localhost:8085/hotelmanagement"), HttpMethod.GET, entity,
				List.class);
		}else {
			System.out.println("Inside service");
			// always no fallback as 8083 will render response
			response = restTemplate.exchange(("http://localhost:8083/hotelmanagement"), HttpMethod.GET, entity,
					List.class);
		}
		List<RoomInventory> hotelList = response.getBody();
		if (hotelList != null) {
			System.out.println("HOtel list is not empty");
			return hotelList;
		}

		return new ArrayList<RoomInventory>();
	}

	/**
	 * Fall back message for hotel listing to give generic error message
	 * @param simulateFallback
	 * @param e
	 * @return
	 */
	public List<RoomInventory> getDefaultHotelListing(Boolean simulateFallback,Throwable e) {
		logger.info("Inside Default listing due to error");
		RoomInventory hotel=new RoomInventory();
		logger.info("Sorry Hotel details Unavailable Currently. Please try again later!!!");
		List<RoomInventory> hotelList=new ArrayList<RoomInventory>();
		hotelList.add(hotel);
		return hotelList;

	}


    public void saveCustomer(Customer customer) {
		customerRepository.save(customer);
		logger.info("Customer details saved successfully!");
	}
    
   	public ResponseEntity<?> deleteCustomer(Long customerId){
        customerRepository.deleteById(customerId);
        return ResponseEntity.ok("Deleted customer! ");
    }
	
}

