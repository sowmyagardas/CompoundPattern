package com.HotelReservationSystem.Event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;

import com.HotelReservationSystem.Entity.Notification;
import com.HotelReservationSystem.Repository.NotificationRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NotificationSourceConsumer {
    private static final Logger logger = LoggerFactory.getLogger(NotificationSourceConsumer.class);

    @Autowired
    NotificationRepository notificationRepo;

    @KafkaListener(topics = "sendNotification", groupId = "myGroup1")
    public void saveNotification(Notification notification) {
         
        	// saves notification. Can be enhanced later to read DB and send emails
    	notificationRepo.save(notification);
        logger.info("Notification message:"+notification.getMessage());             
    }
}
