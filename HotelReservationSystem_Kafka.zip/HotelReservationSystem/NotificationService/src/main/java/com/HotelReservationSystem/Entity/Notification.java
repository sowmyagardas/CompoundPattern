package com.HotelReservationSystem.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Notification {
    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
        private String message;

        public Notification(){

        }
        public Notification(Long id, String msg){
            this.id = id;
            this.message = msg;
        }

        public Long getId(){
            return id;
        }

        public void setId(Long id){
            this.id = id;
        }
        
        public String getMessage(){
            return message;
        }

        public void saveMessage(String message){
            this.message = message;
        }
    
}
