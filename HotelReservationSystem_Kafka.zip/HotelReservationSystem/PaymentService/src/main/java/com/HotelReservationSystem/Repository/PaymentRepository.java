package com.HotelReservationSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.HotelReservationSystem.Entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Long>{

}
