package com.HotelReservationSystem.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.HotelReservationSystem.Entity.Payment;
import com.HotelReservationSystem.Repository.PaymentRepository;

@Service
public class PaymentService {
    @Autowired
	private PaymentRepository paymentRepository;

    public ResponseEntity<?> savePayment(Payment payment) {
        paymentRepository.save(payment);
        return ResponseEntity.ok("Payment successful!");
    }
}
