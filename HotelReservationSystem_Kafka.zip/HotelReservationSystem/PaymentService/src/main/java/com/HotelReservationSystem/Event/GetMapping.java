package com.HotelReservationSystem.Event;

public @interface GetMapping {
    
}
