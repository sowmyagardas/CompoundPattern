package com.HotelReservationSystem.Entity;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private Long hotelId;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate;
    
    public Reservation(Long id, Long customerId, Long hotelId, LocalDate startDate, LocalDate endDate){
        this.id = id;
        this.customerId = customerId;
        this.hotelId = hotelId;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Reservation(){

    }

    public Long getId(){
        return id;
    }
    public Long getCustomerId(){
        return customerId;
    }
    public Long getHotelId(){
        return hotelId;
    }
    public LocalDate getStartDate(){
        return startDate;
    }
    public LocalDate getEndDate(){
        return endDate;
    }
    public void setId(Long id){
        this.id = id;
    }
    public void setCustomerId(Long cid){
        this.customerId = cid;
    }
    public void setHotelId(Long hid){
        this.hotelId = hid;
    }
    public void setStartDate(LocalDate sDate){
        this.startDate = sDate;
    }
    public void setEndDate(LocalDate eDate){
        this.endDate = eDate;
    }
}
