package com.HotelReservationSystem.Client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import com.HotelReservationSystem.Entity.Reservation;

@FeignClient(name = "ReservationService", url = "localhost:8085")
public interface ReservationClient {
    @GetMapping("/reservation")
    List<Reservation> getAllReservation();
}
