package com.HotelReservationSystem.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private Double amount;
    private String paymentStatus;

    public Payment(Long id, Long customerId, Double amount, String status){
        this.id = id;
        this.customerId = customerId;
        this.amount = amount;
        this.paymentStatus = status;
    }

    public Payment(){

    }

    public Long getId(){
        return id;
    }

    public Long getCustomerId(){
        return customerId;
    }

    public Double getAmount(){
        return amount;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setCustomerId(Long cid){
        this.customerId = cid;
    }

    public void setAmount(Double amount){
        this.amount = amount;
    }

    public String getStatus(){
        return paymentStatus;
    }
    public void setStatus(String status){
        this.paymentStatus = status;
    }
}
