package com.HotelReservationSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.HotelReservationSystem.Entity.RoomInventory;

public interface HotelManagementRepository extends JpaRepository<RoomInventory, Long>{
    
}
