package com.HotelReservationSystem.HotelManagementService;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.HotelReservationSystem.Entity.RoomInventory;
import com.HotelReservationSystem.Repository.HotelManagementRepository;

@Service
public class HotelManagementService {
    @Autowired
	private HotelManagementRepository hotelRepository;

    public ResponseEntity<?> saveHotelManagement(RoomInventory hotelManagement) {
        if(! hotelRepository.existsById(hotelManagement.getId())){
            hotelRepository.save(hotelManagement);
            return ResponseEntity.ok("Room Booked successfully!");
        }
        else{
            return ResponseEntity.ok("Room is already Booked!");
        }

    }
    
    public ResponseEntity<?> deleteRoom(Long hotelId){
        hotelRepository.deleteById(hotelId);
        return ResponseEntity.ok("Deleted Room! ");
    }

    public RoomInventory getRoomInventoryAvailability(RoomInventory roomInventory) {
        List<RoomInventory> roomInventoryList = hotelRepository.findAll();
        RoomInventory roomInventoryResult = null;
        roomInventoryList.removeIf(room ->
                !(Objects.equals(room.getId(), roomInventory.getId()) && room.getQuantity() > 0L)
        );
        if (!roomInventoryList.isEmpty()) {
            roomInventoryResult = roomInventoryList.get(0);
        }
        return roomInventoryResult;
    }

    public RoomInventory updateRoomInventory(RoomInventory roomInventory) {            
        Optional<RoomInventory> hotelFound = hotelRepository.findById(roomInventory.getId());
		if (hotelFound.isPresent() && hotelFound.get().getQuantity() > roomInventory.getTotalQuantity()) {
			hotelFound.get().setQuantity(hotelFound.get().getQuantity() - roomInventory.getTotalQuantity());
			hotelRepository.save(hotelFound.get());
			return hotelFound.get();
		}
        return null;
    }
}
