package com.HotelReservationSystem.Event;
 
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.HotelReservationSystem.Entity.RoomInventory;
import com.HotelReservationSystem.Entity.Payment;
import com.HotelReservationSystem.Entity.Reservation;
import com.HotelReservationSystem.Repository.HotelManagementRepository;

@Component
public class HotelEventConsumer {
    @Autowired
    HotelManagementRepository hotelRepo;
    @Autowired
    private KafkaTemplate<String, Payment> kafkaPaymentTemplate;
    @Autowired
    private KafkaTemplate<String, Reservation> kafkaReservationTemplate;

    @KafkaListener(topics = "updateHotel", groupId = "myGroup2")
    public void updateRoomInventory(RoomInventory hotel) {
        try {
        	Optional<RoomInventory> hotelFound=	hotelRepo.findById(hotel.getId());
        	// saga fall back if the room count or room does not exist
        	if(hotelFound.isPresent()&&hotelFound.get().getQuantity()>hotel.getTotalQuantity()) {

    			hotelFound.get().setQuantity(hotelFound.get().getQuantity()-hotel.getTotalQuantity());
    			hotelRepo.save(hotelFound.get());
    			// Saga pattern level 2 --> Invoke payment event
    			Payment payment=new Payment();
    			payment.setAmount(hotel.getAmount());
    			payment.setStatus("Success");
				kafkaPaymentTemplate.send("makePayment",payment);
    		   			 
    		}else {
    			throw new Exception();
    		}
    	
        }catch(Exception e) {
        	// fall back to reverse reservation
        	Reservation reservation=new Reservation();
        	reservation.setId(hotel.getId());
        	kafkaReservationTemplate.send("reverseReservation", reservation);
        }       
     
    }
    
    //Reversal room reservation
    @KafkaListener(topics = "reverseHotelUpdate", groupId = "myGroup5")
    public void reverseRoomInventory(RoomInventory hotel) {
        
        	Optional<RoomInventory> hotelFound=	hotelRepo.findById(hotel.getId());
        	if(hotelFound.isPresent()) {
        		// increase the room counts
    			hotelFound.get().setQuantity(hotelFound.get().getQuantity()+hotel.getTotalQuantity());
    			hotelRepo.save(hotelFound.get());		
        	Reservation reservation=new Reservation();
        	reservation.setId(hotel.getId());
        	// fail reservation reversal called
        	kafkaReservationTemplate.send("reverseReservation", reservation);
        }
    }
     
    
}
