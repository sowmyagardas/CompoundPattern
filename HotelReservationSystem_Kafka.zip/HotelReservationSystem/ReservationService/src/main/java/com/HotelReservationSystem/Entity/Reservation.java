package com.HotelReservationSystem.Entity;

import java.time.LocalDate;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private Long hotelId;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate startDate;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate endDate;
    private String roomType;
    private int quantity;
    private Double bookingAmount;
    
    public Reservation(Long id, Long customerId, Long hotelId, LocalDate startDate, LocalDate endDate,String roomType, int quantity, Double bookingAmount){
        this.id = id;
        this.customerId = customerId;
        this.hotelId = hotelId;
        this.startDate = startDate;
        this.endDate = endDate;
        this.roomType = roomType;
        this.quantity = quantity;
        this.bookingAmount = bookingAmount;
    }

    public Reservation(){

    }

    public Long getId(){
        return id;
    }
    public Long getCustomerId(){
        return customerId;
    }
    public Long getHotelId(){
        return hotelId;
    }
    public LocalDate getStartDate(){
        return startDate;
    }
    public LocalDate getEndDate(){
        return endDate;
    }
    public void setId(Long id){
        this.id = id;
    }
    public void setCustomerId(Long cid){
        this.customerId = cid;
    }
    public void setHotelId(Long hid){
        this.hotelId = hid;
    }
    public void setStartDate(LocalDate sDate){
        this.startDate = sDate;
    }
    public void setEndDate(LocalDate eDate){
        this.endDate = eDate;
    }   
    public String getRoomType(){
        return roomType;
    }

    public int getQuantity(){
        return quantity;
    }

    public Double getBookingAmount(){
        return bookingAmount;
    }

    public void setRoomType(String type){
        this.roomType = type;
    }

    public void setQuantity(int quan){
        this.quantity = quan;
    }

    public void setBookingAmount(Double amt){
        this.bookingAmount = amt;
    }

}
