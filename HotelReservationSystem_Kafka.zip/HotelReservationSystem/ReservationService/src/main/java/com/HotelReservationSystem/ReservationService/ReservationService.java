package com.HotelReservationSystem.ReservationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.HotelReservationSystem.Entity.Notification;
import com.HotelReservationSystem.Entity.Reservation;
import com.HotelReservationSystem.ExceptionHandler.ReservationNotFoundException;
import com.HotelReservationSystem.Entity.Payment;
import com.HotelReservationSystem.Entity.RoomInventory;
import com.HotelReservationSystem.Repository.ReservationRepository;

@Service
public class ReservationService {
    @Autowired
	private ReservationRepository reservationRepository;
    RoomInventory roomInventoryClient;
    Payment paymentClient;
    @Autowired
	private KafkaTemplate<String, Notification> kafkaNotificationTemplate;
	@Autowired
	private KafkaTemplate<String, RoomInventory> kafkaHotelTemplate;
    
    public Reservation saveReservation(Reservation reservation) {
            Reservation savedReservation = reservationRepository.save(reservation);
    
            // Send event to notification service to send notification
            Notification notification = new Notification();
            notification.saveMessage("Room reserved successfully!");
            kafkaNotificationTemplate.send("sendNotification", notification);
            // Level 1 saga pattern to call hotel service to update Hotel room count. If
            // failed, in hotel event reservation status will be reversed to failure
            RoomInventory hotel = new RoomInventory();
            hotel.setId(reservation.getHotelId());
            hotel.setRoomType(reservation.getRoomType());
            hotel.setQuantity(reservation.getQuantity());
            hotel.setAmount(reservation.getBookingAmount());
            kafkaHotelTemplate.send("updateHotel", hotel);
            return savedReservation;
    }

    public ResponseEntity<String> updateReservation(Reservation reservation) {
        Long reservationId = reservation.getId();
        if(! reservationRepository.existsById(reservationId)){
            throw new ReservationNotFoundException("Reservation not found with ID: "+ reservationId);
        }
        Reservation existingReservation = reservationRepository.findById(reservationId).orElse(null);
        if(existingReservation != null){
            existingReservation.setId(reservation.getId());
            existingReservation.setCustomerId(reservation.getCustomerId());
            existingReservation.setHotelId(reservation.getHotelId());
            existingReservation.setStartDate(reservation.getStartDate());
            existingReservation.setEndDate(reservation.getEndDate());
            }
        reservationRepository.save(existingReservation);
        return ResponseEntity.ok("Reservation updated successfully!");
    }

    public ResponseEntity<String> cancelReservation(Long reservationId) {
        if(! reservationRepository.existsById(reservationId)){
            throw new ReservationNotFoundException("Reservation not found with ID: "+ reservationId);
        }
        reservationRepository.deleteById(reservationId);
        return ResponseEntity.ok("Reservation cancelled successfully!");
    }

}
