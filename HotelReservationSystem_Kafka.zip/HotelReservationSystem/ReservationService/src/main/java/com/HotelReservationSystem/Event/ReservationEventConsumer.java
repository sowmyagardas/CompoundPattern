package com.HotelReservationSystem.Event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.HotelReservationSystem.Entity.Reservation;
import com.HotelReservationSystem.Repository.ReservationRepository;

@Component
public class ReservationEventConsumer {
    @Autowired
    ReservationRepository ReservationRepo;

    @KafkaListener(topics = "reverseReservation", groupId = "myGroup3")
    public void reverseReservation(Reservation Reservation) {
            // reverse status to failure
        	ReservationRepo.save(Reservation);
            System.out.println("Received Message in group reverse Reservation : " + Reservation);
    }
}