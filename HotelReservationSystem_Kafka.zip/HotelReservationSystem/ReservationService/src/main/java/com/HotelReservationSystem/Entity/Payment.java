package com.HotelReservationSystem.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private Status paymentStatus;
    enum Status{
        PENDING,
        COMPLETED,
        FAILED
    }

    public Payment(int i, int j, Status paymentStatus) {
    }

    public Long getId(){
        return id;
    }

    public Long getCustomerId(){
        return customerId;
    }

    public Status getPaymentStatus(){
        return paymentStatus;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setCustomerId(Long cid){
        this.customerId = cid;
    }

    public void setPaymentStatus(Status status){
        this.paymentStatus = status;
    }

}
