package com.HotelReservationSystem.Model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long customerId;
    private Status paymentStatus;
    enum Status{
        PENDING,
        COMPLETED,
        FAILED
    }

    public Payment(int i, int j, Status paymentStatus) {
    }

    public Long getId(){
        return id;
    }

    public Long getCustomerId(){
        return customerId;
    }

    public Status getPaymentStatus(){
        return paymentStatus;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setCustomerId(Long cid){
        this.customerId = cid;
    }

    public void setPaymentStatus(Status status){
        this.paymentStatus = status;
    }

}
