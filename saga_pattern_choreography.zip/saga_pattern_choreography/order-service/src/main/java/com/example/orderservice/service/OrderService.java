package com.example.orderservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.example.orderservice.entity.OrderDetails;
import com.example.orderservice.entity.Payment;
import com.example.orderservice.repository.OrderRepository;

@Service
public class OrderService {
	
	@Autowired
    private KafkaTemplate<String, Payment> kafkaTemplate;
	
	@Autowired
	private OrderRepository orderRepo;
		
		 public OrderDetails saveOrder(OrderDetails order){
			 OrderDetails savedOrder = orderRepo.save(order);
			 Payment payment=new Payment();
			 savedOrder.setOrderStatus("Success");
			 payment.setOrderId(savedOrder.getId());
			 payment.setAmount(order.getOrderAmount());
			 
		        kafkaTemplate.send("makePayment", payment);
		        return savedOrder;
		    }

}
