package com.rest.rates;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
