package github.io.truongbn.paymentprocessor.service;

public interface PaymentProcessorService {
    String processPayment(String paymentInfo);
}
