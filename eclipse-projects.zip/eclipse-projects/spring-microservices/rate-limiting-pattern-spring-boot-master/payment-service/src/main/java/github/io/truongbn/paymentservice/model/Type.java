package github.io.truongbn.paymentservice.model;

public interface Type {
}
