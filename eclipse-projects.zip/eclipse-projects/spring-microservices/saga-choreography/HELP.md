# Saga Pattern - Orchestration

This is a sample project to demo saga pattern.

## Prerequisites:

* Kafka cluster
* use the docker-compose file for setting up the cluster

# High Level Architecture

![](doc/saga-choreography.png)