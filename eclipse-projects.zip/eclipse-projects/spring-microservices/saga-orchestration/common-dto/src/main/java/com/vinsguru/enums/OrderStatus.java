package com.vinsguru.enums;

public enum OrderStatus {

    ORDER_CREATED,
    ORDER_CANCELLED,
    ORDER_COMPLETED

}