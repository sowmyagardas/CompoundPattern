package com.vinsguru.enums;

public enum  InventoryStatus {
    AVAILABLE,
    UNAVAILABLE;
}
