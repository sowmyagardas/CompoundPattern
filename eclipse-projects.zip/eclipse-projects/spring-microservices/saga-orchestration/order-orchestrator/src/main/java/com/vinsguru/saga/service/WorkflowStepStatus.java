package com.vinsguru.saga.service;

public enum WorkflowStepStatus {
    PENDING,
    COMPLETE,
    FAILED;
}
