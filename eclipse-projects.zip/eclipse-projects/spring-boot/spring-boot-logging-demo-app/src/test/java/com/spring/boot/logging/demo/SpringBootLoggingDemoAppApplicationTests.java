package com.spring.boot.logging.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLoggingDemoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
