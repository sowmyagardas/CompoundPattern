package demo.microservices.boot.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuotersRestfulApplicationTests {

	@Test
	void contextLoads() {
	}

}
