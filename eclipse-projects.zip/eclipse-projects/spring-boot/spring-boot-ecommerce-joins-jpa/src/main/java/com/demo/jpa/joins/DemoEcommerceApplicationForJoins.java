package com.demo.jpa.joins;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoEcommerceApplicationForJoins {

	public static void main(String[] args) {
		SpringApplication.run(DemoEcommerceApplicationForJoins.class, args);
	}

}
