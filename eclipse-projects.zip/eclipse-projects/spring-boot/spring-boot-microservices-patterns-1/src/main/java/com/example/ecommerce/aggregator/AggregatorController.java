package com.example.ecommerce.aggregator;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.ecommerce.proxy.ProductServiceProxy;

public class AggregatorController {

    @Autowired
    private ProductServiceProxy productServiceProxy;
    

	
}
