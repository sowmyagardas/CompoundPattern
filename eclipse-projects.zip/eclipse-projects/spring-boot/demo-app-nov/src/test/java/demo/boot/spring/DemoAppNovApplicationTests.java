package demo.boot.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAppNovApplicationTests {

	@Test
	void contextLoads() {
	}

}
