package demo.microservices.messaging.patterns.claim.check;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClaimCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClaimCheckApplication.class, args);
	}

}
