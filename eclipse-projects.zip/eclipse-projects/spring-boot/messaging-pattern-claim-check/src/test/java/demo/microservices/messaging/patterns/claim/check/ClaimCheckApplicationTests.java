package demo.microservices.messaging.patterns.claim.check;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClaimCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
