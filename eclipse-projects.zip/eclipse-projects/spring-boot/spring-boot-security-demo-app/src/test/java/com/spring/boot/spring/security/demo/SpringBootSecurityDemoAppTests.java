package com.spring.boot.spring.security.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSecurityDemoAppTests {

	@Test
	void contextLoads() {
	}

}
