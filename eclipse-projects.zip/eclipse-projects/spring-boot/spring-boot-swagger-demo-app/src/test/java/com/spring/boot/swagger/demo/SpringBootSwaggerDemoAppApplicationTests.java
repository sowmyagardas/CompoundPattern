package com.spring.boot.swagger.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSwaggerDemoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
