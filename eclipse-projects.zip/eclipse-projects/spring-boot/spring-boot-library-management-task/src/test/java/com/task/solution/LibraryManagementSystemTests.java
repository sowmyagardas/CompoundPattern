package com.task.solution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManagementSystemTests {

	@Test
	void contextLoads() {
	}

}
