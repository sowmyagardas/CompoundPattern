package com.spring.boot.spring.security.auth.demo.projections;

public interface ProjectTitleAndDescription {
	String getTitle();
	String getDescription();
}
