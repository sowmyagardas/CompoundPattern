/**
 * 
 */
package com.springdemo;

/**
 * @author Akash
 *
 * Second bean class to demonstrate bean definition inheritance
 */
public class HelloIndia {
	private String message1;
	private String message2;
	private String message3;
	
	/**
	 * @return the message1
	 */
	public String getMessage1() {
		return message1;
	}
	/**
	 * @param message1 the message1 to set
	 */
	public void setMessage1(String message1) {
		this.message1 = message1;
	}
	/**
	 * @return the message2
	 */
	public String getMessage2() {
		return message2;
	}
	/**
	 * @param message2 the message2 to set
	 */
	public void setMessage2(String message2) {
		this.message2 = message2;
	}
	/**
	 * @return the message3
	 */
	public String getMessage3() {
		return message3;
	}
	/**
	 * @param message3 the message3 to set
	 */
	public void setMessage3(String message3) {
		this.message3 = message3;
	}
	
	
}
