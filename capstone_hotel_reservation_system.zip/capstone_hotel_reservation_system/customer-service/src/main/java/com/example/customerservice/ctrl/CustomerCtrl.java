package com.example.customerservice.ctrl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.customerservice.CustomerService;
import com.example.customerservice.entity.Customer;
import com.example.customerservice.entity.HotelRoom;
import com.example.customerservice.repository.CustomerRepository;

@RestController
@RequestMapping("/customer")
public class CustomerCtrl {

	@Autowired
	private CustomerRepository customerRepo;

	@Autowired
	private CustomerService customerService;

	@PostMapping
	public Customer create(@RequestBody Customer customer) {
		return customerService.createCustomer(customer);
	}

	@PostMapping
	@RequestMapping("/updateCustomer")
	public Customer updateCustomer(@RequestBody Customer customer) {
		return customerService.updateCustomer(customer);
	}

	@GetMapping
	public List<Customer> getAllCustomer() {
		return customerRepo.findAll();
	}

	@GetMapping("/{id}")
	public Optional<Customer> findById(@PathVariable Long id) {
		return customerRepo.findById(id);
	}

	/**
	 * simulateFallback true : circuit breaker will be invoked simulateFallback
	 * false : with 8083 port on will have normal flow
	 * 
	 * @param simulateFallback
	 * @return
	 */
	@GetMapping
	@RequestMapping("/getHotelListing/{simulateFallback}")
	public List<HotelRoom> getHotelListing(@PathVariable Boolean simulateFallback) {
		return customerService.getHotelListing(simulateFallback);
	}

}
