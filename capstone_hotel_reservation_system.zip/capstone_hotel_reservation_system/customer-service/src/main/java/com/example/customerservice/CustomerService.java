package com.example.customerservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.customerservice.entity.Customer;
import com.example.customerservice.entity.HotelRoom;
import com.example.customerservice.entity.Notification;
import com.example.customerservice.repository.CustomerRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private KafkaTemplate<String, Notification> kafkaTemplate;
	 private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);

	/**
	 * Service to create a customer and send notification
	 * 
	 * @param customer
	 * @return
	 */
	public Customer createCustomer(Customer customer) {
		customer.setStatus("Success");
		// Creates customer in DB
		Customer savedCustomer = customerRepo.save(customer);
		// Send event to notification service to send notification
		Notification notification = new Notification();
		notification.setEmail(customer.getEmail());
		notification.setNotificationType("Create_Customer");
		notification.setNotificationDescription("Customer :" + customer.getUserId() + "Created successfully");
		kafkaTemplate.send("createNotification", notification);
		return savedCustomer;
	}

	/**
	 * Updates customer and send notification
	 * 
	 * @param customer
	 * @return
	 */
	public Customer updateCustomer(Customer customer) {
		Optional<Customer> customerFound = customerRepo.findById(customer.getId());
		if (customerFound.isPresent()) {

			customerRepo.save(customer);
			// Send event to notification service to send notification
			Notification notification = new Notification();
			notification.setEmail(customer.getEmail());
			notification.setNotificationType("Update_Customer");
			notification.setNotificationDescription("Customer :" + customer.getUserId() + "Updated successfully");
			kafkaTemplate.send("createNotification", notification);
			return customer;
		}
		// Error case status would indicate failure
		customer.setStatus("Failed Update due to customer not found");
		return customer;

	}

	@CircuitBreaker(name = "hotermgmt-service", fallbackMethod = "getDefaultHotelListing")
	public List<HotelRoom> getHotelListing(Boolean simulateFallback) {

		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List> entity = new HttpEntity<>(null, headers);
		ResponseEntity<List> response =null;
		// Rest Template implementation
		// Actual service runs in 8083 port. To simulate circuit breaker 8085 port
		// applied so that fallback method gets called
		if(simulateFallback) {
		 response = restTemplate.exchange(("http://localhost:8085/hotel"), HttpMethod.GET, entity,
				List.class);
		}else {
			// always no fallback as 8083 will render response
			response = restTemplate.exchange(("http://localhost:8083/hotel"), HttpMethod.GET, entity,
					List.class);
		}
		List<HotelRoom> hotelList = response.getBody();
		if (hotelList != null) {
			return hotelList;
		}

		return new ArrayList<HotelRoom>();
	}

	/**
	 * Fall back message for hotel listing to give generic error message
	 * @param simulateFallback
	 * @param e
	 * @return
	 */
	public List<HotelRoom> getDefaultHotelListing(Boolean simulateFallback,Throwable e) {
		logger.info("Inside Default listing due to error");
		HotelRoom hotel=new HotelRoom();
		hotel.setAvailableStatus("Sorry Hotel details Unavailable Currently. Please try again later!!!");
		List<HotelRoom> hotelList=new ArrayList<HotelRoom>();
		hotelList.add(hotel);
		return hotelList;

	}

}
