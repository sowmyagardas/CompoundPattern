Hotel Reservation System
-------------------------

customer-service - addCustomer / updateCustomer / ViewAllCustomer / viewCustomerById / viewHotelListing
hotel-mgmtservice - Create hotel details / update details through events / View hotel details / View Reservation details
reservation-service - Create reservation / event for reverse reservation / view All reservations
payment-service -event for makePayment / View all payments
notification-service  - Event source / kind of CQRS having event for notifcation of customer / payment creations
gateway-api - Map all service APIs to generic gateway port

Microservice concepts / design patterns used:
----------------------------------------------

1. RestTemplate - synchronous API call to get hotellisting in customer service
2. CircuitBreaker - if hostellisting API calls fails, fall back implemented to give default message (simulated fallback by input in get method)
3. Feign client - Synchronous API call to get list of reservations in hotelmgmt-service
4. Event Driven Approach using Kafka - Asynchronous call - Notification-service / Saga pattern implementation 
5. Saga Pattern - Reserve room
	Success flow : reservation-service --> hotel-service (update room counts) --> Payment service
	Failure in updating room: room-service --> reverse reservation [Exception occurs if unavailable room id / more rooms requested than avaiable)
	Failure in payment: payment service --> update room-service to increment rooms --> reverse reservation
6. API Gateway pattern
7. Proxy filter in API gateway - Validates API coming though gateway should have password --> Welcome@123 (direct api calls will work. Gateway based will fail without header TOKEN having value Welcome@123
