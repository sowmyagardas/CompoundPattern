package com.example.gatewayservice;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import reactor.core.publisher.Mono;

@Component
public class AuthFilter implements GlobalFilter {

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
		System.out.println("Global Pre Filter executed");
		System.out.println("Token value" + exchange.getRequest().getHeaders().get("TOKEN"));
		// Validates gateway API to have header value as Welcome@123. If invalid sends
		// null due to which API redirection is not happening
		if (!"[Welcome@123]".equalsIgnoreCase(exchange.getRequest().getHeaders().get("TOKEN").toString())) {
			System.out.println("****" + exchange.getApplicationContext().getApplicationName());
			return chain.filter(null);
		}
		// Proper header with token value right API will be called
		return chain.filter(exchange);
	}

}
