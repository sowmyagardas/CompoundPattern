package com.example.hotelmgmtservice.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.hotelmgmtservice.entity.Reservation;

@FeignClient(name = "reservation-service", url = "localhost:8084")
public interface ReservationClient {
    @GetMapping("/reservation")
    List<Reservation> getAllReservation();
}