package com.example.hotelmgmtservice.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hotelmgmtservice.entity.HotelRoom;

public interface HotelRepository extends JpaRepository<HotelRoom, Long> {}
