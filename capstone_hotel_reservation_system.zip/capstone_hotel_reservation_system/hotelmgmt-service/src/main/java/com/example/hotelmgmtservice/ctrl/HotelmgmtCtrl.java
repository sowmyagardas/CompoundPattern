package com.example.hotelmgmtservice.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.hotelmgmtservice.HotelmgmtService;
import com.example.hotelmgmtservice.client.ReservationClient;
import com.example.hotelmgmtservice.entity.HotelRoom;
import com.example.hotelmgmtservice.entity.Reservation;
import com.example.hotelmgmtservice.repository.HotelRepository;

@RestController
@RequestMapping("/hotel")
public class HotelmgmtCtrl {
	 
	@Autowired
	private HotelRepository hotelRepo;
	
	@Autowired
	private HotelmgmtService hotelService;

	 @Autowired
	    private ReservationClient reservationClient;
	
	@PostMapping
	public HotelRoom create(@RequestBody HotelRoom hotelRoom) {
		return hotelService.saveHotel(hotelRoom);
	}
	@PostMapping
	@RequestMapping("/updateHotelRoom")
	public HotelRoom updateProduct(@RequestBody HotelRoom hotelRoom) {
		return hotelService.update(hotelRoom);
	}
	
	@GetMapping	
	public List<HotelRoom> getAllHotelRooms() {
		return hotelRepo.findAll();
	}
	
	 
	/**
	 * Feign client implementation to get reservations
	 * @return
	 */
	@GetMapping	
	@RequestMapping("/getReservation")
	public List<Reservation> getAllReservation() {
		 return reservationClient.getAllReservation();
	}
	 
	

}
