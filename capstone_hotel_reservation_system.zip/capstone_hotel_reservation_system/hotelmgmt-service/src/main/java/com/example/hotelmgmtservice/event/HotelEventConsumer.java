package com.example.hotelmgmtservice.event;
 
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.example.hotelmgmtservice.entity.HotelRoom;
import com.example.hotelmgmtservice.entity.Payment;
import com.example.hotelmgmtservice.entity.Reservation;
import com.example.hotelmgmtservice.repository.HotelRepository;

@Component
public class HotelEventConsumer {
    @Autowired
    HotelRepository hotelRepo;
    @Autowired
    private KafkaTemplate<String, Payment> kafkaPaymentTemplate;
    @Autowired
    private KafkaTemplate<String, Reservation> kafkaReservationTemplate;

    @KafkaListener(topics = "updateHotel", groupId = "myGroup2")
    public void updateHotelRoom(HotelRoom hotel) {
        try {
        	Optional<HotelRoom> hotelFound=	hotelRepo.findById(hotel.getId());
        	// saga fall back if the room count or room does not exist
        	if(hotelFound.isPresent()&&hotelFound.get().getAvailableQuantity()>hotel.getTotalQuantity()) {

    			hotelFound.get().setAvailableQuantity(hotelFound.get().getAvailableQuantity()-hotel.getTotalQuantity());
    			hotelRepo.save(hotelFound.get());
    			// Saga pattern level 2 --> Invoke payment event
    			Payment payment=new Payment();
    			payment.setAmount(hotel.getPrice());
    			payment.setReservationId(hotel.getReservationId());
    			payment.setQuantity(hotel.getTotalQuantity());
    			payment.setEmail(hotel.getEmail());
    			payment.setCustomerId(hotel.getCustomerId());
    			payment.setRoomId(hotel.getId());
    			kafkaPaymentTemplate.send("makePayment",payment);
    		
    			 
    		}else {
    			throw new Exception();
    		}
    	
        }catch(Exception e) {
        	// fall back to reverse reservation
        	Reservation reservation=new Reservation();
        	reservation.setId(hotel.getReservationId());
        	reservation.setReservationStatus("Failed");
        	 kafkaReservationTemplate.send("reverseReservation", reservation);
        }
        
     
    }
    
    /**
     * Reversal on payment failure
     * @param hotel
     */
    @KafkaListener(topics = "reverseHotelUpdate", groupId = "myGroup5")
    public void reverseHotelRoom(HotelRoom hotel) {
        
        	Optional<HotelRoom> hotelFound=	hotelRepo.findById(hotel.getId());
        	if(hotelFound.isPresent()) {
        		// increase the room counts
    			hotelFound.get().setAvailableQuantity(hotelFound.get().getAvailableQuantity()+hotel.getTotalQuantity());
    			hotelRepo.save(hotelFound.get());		
        	Reservation reservation=new Reservation();
        	reservation.setId(hotel.getReservationId());
        	// fail reservation reversal called
        	reservation.setReservationStatus("Failed");
        	 kafkaReservationTemplate.send("reverseReservation", reservation);
        }
    }
     
    
}
