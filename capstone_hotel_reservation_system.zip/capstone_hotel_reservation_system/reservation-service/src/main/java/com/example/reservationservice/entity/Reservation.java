package com.example.reservationservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Reservation {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	 	private Long customerId;
	 	private String email;
	 	private Double price;
		public Double getPrice() {
			return price;
		}
		public void setPrice(Double price) {
			this.price = price;
		}
	 	public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		private Long roomId;
	 	private Long quantity;
	 	public Long getQuantity() {
			return quantity;
		}
		public void setQuantity(Long quantity) {
			this.quantity = quantity;
		}
		
		public Long getCustomerId() {
			return customerId;
		}
		public void setCustomerId(Long customerId) {
			this.customerId = customerId;
		}
		private Double reservationAmount;
	 	private String reservationStatus;
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Long getRoomId() {
			return roomId;
		}
		public void setRoomId(Long roomId) {
			this.roomId = roomId;
		}
		public Double getReservationAmount() {
			return reservationAmount;
		}
		public void setReservationAmount(Double reservationAmount) {
			this.reservationAmount = reservationAmount;
		}
		public String getReservationStatus() {
			return reservationStatus;
		}
		public void setReservationStatus(String reservationStatus) {
			this.reservationStatus = reservationStatus;
		}
		

}
