package com.example.reservationservice.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class HotelRoom {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;
	 private Long reservationId;	 
		private String hotelRoomType;
		private String accomodationSize;
	 	private Long totalQuantity;
	 	private Long availableQuantity;
	 	private boolean isAirConditioned;
	 	private String availableStatus;
	 	private Double price;
	 	private Long customerId;
	 	private String email;
		public Long getCustomerId() {
			return customerId;
		}
		public void setCustomerId(Long customerId) {
			this.customerId = customerId;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public Double getPrice() {
			return price;
		}
		public void setPrice(Double price) {
			this.price = price;
		}
		public String getAvailableStatus() {
			return availableStatus;
		}
		public void setAvailableStatus(String availableStatus) {
			this.availableStatus = availableStatus;
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public Long getReservationId() {
			return reservationId;
		}
		public void setReservationId(Long reservationId) {
			this.reservationId = reservationId;
		}
		public String getHotelRoomType() {
			return hotelRoomType;
		}
		public void setHotelRoomType(String hotelRoomType) {
			this.hotelRoomType = hotelRoomType;
		}
		public String getAccomodationSize() {
			return accomodationSize;
		}
		public void setAccomodationSize(String accomodationSize) {
			this.accomodationSize = accomodationSize;
		}
		public Long getTotalQuantity() {
			return totalQuantity;
		}
		public void setTotalQuantity(Long totalQuantity) {
			this.totalQuantity = totalQuantity;
		}
		public Long getAvailableQuantity() {
			return availableQuantity;
		}
		public void setAvailableQuantity(Long availableQuantity) {
			this.availableQuantity = availableQuantity;
		}
		public boolean isAirConditioned() {
			return isAirConditioned;
		}
		public void setAirConditioned(boolean isAirConditioned) {
			this.isAirConditioned = isAirConditioned;
		}
		
}
