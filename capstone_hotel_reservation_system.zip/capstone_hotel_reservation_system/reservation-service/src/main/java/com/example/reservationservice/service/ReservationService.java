package com.example.reservationservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.example.reservationservice.entity.HotelRoom;
import com.example.reservationservice.entity.Notification;
import com.example.reservationservice.entity.Reservation;
import com.example.reservationservice.repository.ReservationRepository;

@Service
public class ReservationService {

	 

	@Autowired
	private KafkaTemplate<String, Notification> kafkaNotificationTemplate;

	@Autowired
	private KafkaTemplate<String, HotelRoom> kafkaHotelTemplate;

	@Autowired
	private ReservationRepository reservationRepo;

	public Reservation saveReservation(Reservation reservation) {
		reservation.setReservationStatus("Success");
		Reservation savedReservation = reservationRepo.save(reservation);

		// Send event to notification service to send notification
		Notification notification = new Notification();
		notification.setEmail(reservation.getEmail());
		notification.setNotificationType("Reserve Hotel");
		notification.setNotificationDescription("Reservation :" + savedReservation.getId() + "initiated successfully");
		kafkaNotificationTemplate.send("createNotification", notification);
		// Level 1 saga pattern to call hotel service to update Hotel room count. If
		// failed, in hotel event reservation status will be reversed to failure
		HotelRoom hotel = new HotelRoom();
		hotel.setId(reservation.getRoomId());
		hotel.setTotalQuantity(reservation.getQuantity());
		hotel.setReservationId(savedReservation.getId());
		hotel.setPrice(reservation.getPrice());
		hotel.setEmail(reservation.getEmail());
		hotel.setCustomerId(reservation.getCustomerId());
		kafkaHotelTemplate.send("updateHotel", hotel);
		return savedReservation;
	}

}
