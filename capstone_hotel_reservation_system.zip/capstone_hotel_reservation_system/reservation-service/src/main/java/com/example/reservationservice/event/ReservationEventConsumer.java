package com.example.reservationservice.event;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.example.reservationservice.entity.Reservation;
import com.example.reservationservice.repository.ReservationRepository;

@Component
public class ReservationEventConsumer {
    @Autowired
    ReservationRepository reservationRepo;

    @KafkaListener(topics = "reverseReservation", groupId = "myGroup3")
    public void reverseReservation(Reservation order) {
         
        	// reverse status to failure
        	reservationRepo.save(order);
        
        
        System.out.println("Received Message in group update / create reverse Report: " + order);
    }
}
