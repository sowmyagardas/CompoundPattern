package com.example.notificationservice.ctrl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.notificationservice.entity.Notification;
import com.example.notificationservice.repository.NotificationRepository;

@RestController
@RequestMapping("/notification")
public class NotificationCtrl {
	
	@Autowired
	private NotificationRepository notificationRepo;
	 
	@GetMapping	
	public List<Notification> getAllNotification() {
		return notificationRepo.findAll();
	}
	
	@GetMapping	
	@RequestMapping("/{id}")
	public Optional<Notification> findById(@PathVariable Long id) {
		return notificationRepo.findById(id);
	}
	
	
 
}
