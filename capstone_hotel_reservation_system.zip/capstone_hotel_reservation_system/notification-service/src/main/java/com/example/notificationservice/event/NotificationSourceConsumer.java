package com.example.notificationservice.event;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.example.notificationservice.entity.Notification;
import com.example.notificationservice.repository.NotificationRepository;

@Component
public class NotificationSourceConsumer {
	 private static final Logger logger = LoggerFactory.getLogger(NotificationSourceConsumer.class);

    @Autowired
    NotificationRepository notificationRepo;

    @KafkaListener(topics = "createNotification", groupId = "myGroup1")
    public void reverseOrder(Notification notification) {
         
        	// saves notification. Can be enhanced later to read DB and send emails
    	notificationRepo.save(notification);
        logger.info("Notification Details:"+notification.getNotificationType()+" Notification email:"+notification.getEmail());
        
        
    }
}
