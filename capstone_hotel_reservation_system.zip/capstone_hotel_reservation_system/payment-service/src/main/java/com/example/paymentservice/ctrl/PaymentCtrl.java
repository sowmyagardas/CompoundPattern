package com.example.paymentservice.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.paymentservice.entity.Payment;
import com.example.paymentservice.repository.PaymentRepository;

@RestController
@RequestMapping("/payment")
public class PaymentCtrl {
	 
	@Autowired
	private PaymentRepository paymentRepo;
	
	 
	
	 
	
	@GetMapping	
	public List<Payment> getAllPayments() {
		return paymentRepo.findAll();
	}
	
	 
	
	 
	

}
