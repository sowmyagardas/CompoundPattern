package com.example.paymentservice.event;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.example.paymentservice.entity.HotelRoom;
import com.example.paymentservice.entity.Notification;
import com.example.paymentservice.entity.Payment;
import com.example.paymentservice.repository.PaymentRepository;

@Component
public class PaymentEventConsumer {
    @Autowired
    PaymentRepository paymentRepo;
    @Autowired
    private KafkaTemplate<String, Notification> kafkaTemplate;
    @Autowired
    private KafkaTemplate<String, HotelRoom> kafkaRoomTemplate;

    @KafkaListener(topics = "makePayment", groupId = "myGroup4")
    public void updateProduct(Payment payment) {
        try {
        	// simulate saga fallback if payment amount greater than 50000
        	if(payment.getAmount()<50000) {
        		// update payment success
        		payment.setPaymentStatus("Success");
    			paymentRepo.save(payment);	
    			// send success notification
    			Notification notification = new Notification();
    			notification.setEmail(payment.getEmail());
    			notification.setNotificationType("Payment_Initiate");
    			notification.setNotificationDescription("Payment id :" + payment.getId() + "Initiated successfully");
    			kafkaTemplate.send("createNotification", notification);
        	}
    			 else {
    			throw new Exception();
    		}
    	
        }catch(Exception e) {
        	// reverse hotel room counts
        	HotelRoom hotelRoom=new HotelRoom();
        	hotelRoom.setReservationId(payment.getReservationId());
        	hotelRoom.setId(payment.getRoomId());
        	hotelRoom.setTotalQuantity(payment.getQuantity());
        	kafkaRoomTemplate.send("reverseHotelUpdate", hotelRoom);
        	payment.setPaymentStatus("Failed");
			paymentRepo.save(payment);
			// send failure notification
        	Notification notification = new Notification();
			notification.setEmail(payment.getEmail());
			notification.setNotificationType("Payment_Failed");
			notification.setNotificationDescription("Payment id :" + payment.getId() + "Failed");
			kafkaTemplate.send("createNotification", notification);
        }
        
     
    }
}
