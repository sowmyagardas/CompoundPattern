package com.example.eurekaclient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @Autowired
    private MicroserviceFeignClient fClient;
    
    @GetMapping("/hello")
    public String hello(){
        return "Hello from Microservice!";
    }

    @GetMapping("/hello-from-another")
    public String helloFromAnother()
    {
        return "Response from another microservice:" + fClient.getHello();
    }
}
