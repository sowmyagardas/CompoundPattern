package com.example.eurekaclient;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "microservice")
public interface MicroserviceFeignClient {
    @GetMapping("/hello")
    String getHello();    
}
