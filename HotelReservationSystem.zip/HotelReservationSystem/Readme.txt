Hotel Reservation System
-------------------------
CustomerService
	-signUp a new Customer
	-update the details of existing Custom
	-viewAllCustomer
	-viewCustomerById
	-viewHotelListing 
	-delete customer details
HotelManagementService 
	- Book Room in a hotel 
	- viewHotelById 
	- viewAllRooms
	- getRoomAvailability
	- update room details through events
	- delete Room 
	- View Reservation details
ReservationService 
	- Create reservation
	- event for reverse reservation
	- view All reservations
	- viewReservationById
	- updateReservation
	- cancelreservation
PaymentService 
	- event for makePayment
	- view payment by id
NotificationService  
	- save Notification
	- viewAllNotifcations
	- view NotificationById
	- send event for notifcation of Customer/RoomInventory/Reservation and Payment creations
ApiGatewayService- Map all service APIs to generic gateway port

Design patterns used:
----------------------------------------------
1. RestTemplate - Customer service to send message to Notfication service and synchronous API call to get hotellisting in CustomerService
2. CircuitBreaker - If hotel listing API calls fails, fall back implemented to give default message (triggered fallback by input in get method)
3. Feign client - Synchronous API call to get list of reservations in HotelManagement service
4. Event Driven Approach using Kafka - Asynchronous call - Notification-service / Saga pattern implementation 
5. Saga Pattern - Reserve room
	Success flow : reservation-service --> hotel-service (update room) --> Payment service
	Failure in updating room: room-service --> reverse reservation [Exception occurs if unavailable room id / more rooms requested than avaiable)
	Failure in payment: payment service --> update room-service to increment rooms --> reverse reservation
6. API Gateway pattern
7. Proxy filter in API gateway - Validates API coming though gateway should have password --> Welcome@123 (direct api calls will work. Gateway based will fail without header TOKEN having value Welcome@123
