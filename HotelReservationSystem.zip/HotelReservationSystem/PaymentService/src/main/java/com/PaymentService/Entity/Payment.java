package com.PaymentService.Entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "payments")
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "customerId", nullable = false)
    private Long customerId;
    
    @Column(name = "amount", nullable = false)
    private BigDecimal amount;
    
    // Additional fields such as payment method, status etc.

    // Getters and setters...
    public Long getPaymentId(){
        return id;
    }

    public Long getCustomerId(){
        return customerId;
    }

    public BigDecimal getAmount(){
        return amount;
    }

    public void setPaymentId(Long id){
        this.id = id;
    }

    public void setCustomerId(Long cid){
        this.customerId = cid;
    }

    public void setAmount(BigDecimal amt){
        this.amount = amt;
    }
}
