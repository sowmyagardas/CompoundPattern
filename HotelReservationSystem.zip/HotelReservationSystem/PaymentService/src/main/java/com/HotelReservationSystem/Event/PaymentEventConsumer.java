package  com.HotelReservationSystem.Event;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.HotelReservationSystem.Entity.RoomInventory;
import com.HotelReservationSystem.Entity.Notification;
import com.HotelReservationSystem.Repository.PaymentRepository;
import com.HotelReservationSystem.Entity.Payment;

@Component
public class PaymentEventConsumer {
    @Autowired
    PaymentRepository paymentRepo;
    @Autowired
    private KafkaTemplate<String, Notification> kafkaTemplate;
    @Autowired
    private KafkaTemplate<String, RoomInventory> kafkaRoomTemplate;

    @KafkaListener(topics = "makePayment", groupId = "myGroup4")
    public void updatePayment(Payment payment) {
        try {
        	// Saga fallback to reverse the room booking if payment amount greater than 50000
        	if(payment.getAmount() < 50000.00) {
				payment.setStatus("Success");
        		paymentRepo.save(payment);	
    			// send success notification
    			Notification notification = new Notification();
    			notification.setMessage("Payment Successful!");
    			kafkaTemplate.send("sendNotification", notification);
        	}
    		else {
    			throw new Exception();
    		}
    	
        }catch(Exception e) {
        	// reverse hotel room booking
        	RoomInventory roomInventory=new RoomInventory();
        	roomInventory.setId(payment.getId());
        	roomInventory.setAmount(payment.getAmount());
        	kafkaRoomTemplate.send("reverseHotelUpdate", roomInventory);
        	payment.setStatus("Failed");
			paymentRepo.save(payment);
			// send failure notification
        	Notification notification = new Notification();
			notification.setMessage("Payment Failed!");
			kafkaTemplate.send("sendNotification", notification);
        }
            
    }
}
