package com.HotelReservationSystem.Event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.HotelReservationSystem.Entity.Reservation;
import com.HotelReservationSystem.Repository.ReservationRepository;
import com.HotelReservationSystem.ReservationService.ReservationService;

@Component
public class ReservationEventConsumer {
    @Autowired
    ReservationRepository ReservationRepo;
    @Autowired
    ReservationService reservationService;

    @KafkaListener(topics = "reverseReservation", groupId = "myGroup3")
    public void reverseReservation(Reservation reservation) {
            reservationService.cancelReservation(reservation.getId());
            ReservationRepo.save(reservation);
            System.out.println("Received Message in group reverse Reservation : " + reservation);
    }
}