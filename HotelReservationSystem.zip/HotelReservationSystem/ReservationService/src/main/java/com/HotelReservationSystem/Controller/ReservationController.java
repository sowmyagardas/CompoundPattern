package com.HotelReservationSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HotelReservationSystem.Entity.Reservation;
import com.HotelReservationSystem.Repository.ReservationRepository;
import com.HotelReservationSystem.ExceptionHandler.ReservationNotFoundException;
import com.HotelReservationSystem.ReservationService.ReservationService;

@RestController
@RequestMapping("/reservation")
public class ReservationController {
    @Autowired
    private ReservationService reservationService;
    @Autowired
    private ReservationRepository reservationRepo;
	
	@PostMapping
	public void makeReservation(@RequestBody Reservation reservation) {
            reservationService.saveReservation(reservation);
    }

    @GetMapping("/{id}")
    public Reservation getReservationById(@PathVariable Long id) {
        return reservationRepo.findById(id).orElse(null);
    }

    @GetMapping
    public List<Reservation> getAllReservations() {
		return reservationRepo.findAll();
	}

    @PutMapping("/update")
    public ResponseEntity<String> updateReservation(@RequestBody Reservation reservation) {
        try{
            reservationService.updateReservation(reservation);
            return ResponseEntity.ok("Reservation updated successfully!");
        } catch(ReservationNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Reservation not found");
        }              
    }

    @DeleteMapping("/{reservationId}")
    public ResponseEntity<?> cancelReservation(@PathVariable Long reservationId) {
        try{
            reservationService.cancelReservation(reservationId);
            return ResponseEntity.ok("Reservation cancelled successfully!");
        } catch(ReservationNotFoundException e){
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Reservation not found");
        }
        
    }
}