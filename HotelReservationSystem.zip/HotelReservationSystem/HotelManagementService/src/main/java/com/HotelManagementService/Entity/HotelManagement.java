package com.HotelManagementService.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "hotelmanagement")
public class HotelManagement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "roomAvailbility", nullable = false)
    private Boolean availability;

    @Column(name = "roomType", nullable = false)
    private String type;

    @Column(name = "roomPrice", nullable = false)
    private Double price;

    public Long getRoomId(){
        return id;
    }

    public Boolean getRoomAvailability(){
        return availability;
    } 

    public String getRoomType(){
        return type;
    }

    public Double getRoomPrice(){
        return price;
    }

    public void setRoomId(Long id){
        this.id = id;
    }

    public void setRoomAvailability(Boolean avail){
        this.availability = avail;
    }

    public void setRoomType(String type){
        this.type = type;
    }

    public void setRoomPrice(Double price){
        this.price = price;
    }
}