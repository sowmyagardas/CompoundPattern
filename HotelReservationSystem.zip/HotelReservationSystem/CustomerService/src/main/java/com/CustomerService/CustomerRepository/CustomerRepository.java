package com.CustomerService.CustomerRepository;

import org.springframework.data.repository.CrudRepository;

import com.CustomerService.Entity.Customer;

public interface CustomerRepository extends CrudRepository<Customer, Long>{
    
}
