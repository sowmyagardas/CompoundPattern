package com.CustomerService.Service;

import org.springframework.stereotype.Service;

import com.CustomerService.CustomerRepository.CustomerRepository;
import com.CustomerService.Entity.Customer;

@Service
public class CustomerService {
    public CustomerRepository customerRepository;

    public Customer createCustomer(Customer customer){
        return customerRepository.save(customer);
    }
}
