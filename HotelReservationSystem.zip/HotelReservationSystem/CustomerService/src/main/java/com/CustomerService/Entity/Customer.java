package com.CustomerService.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "email", unique = true, nullable = false)
    private String email;

    @Column(name = "password", nullable = false)
    private String password;

    public Long getCustomerId(){
        return id;
    }
    
    public String getCustomerName(){
        return name;
    }

    public String getCustomerEmail(){
        return email;
    }

    public String getCustomerPassword(){
        return password;
    }

    public void setCustomerId(Long id){
        this.id = id;
    }

    public void setCustomerName(String name){
        this.name = name;
    }

    public void setCustomerEmail(String email){
        this.email = email;
    }

    public void setCustomerPassword(String password){
        this.password = password;
    }
}
