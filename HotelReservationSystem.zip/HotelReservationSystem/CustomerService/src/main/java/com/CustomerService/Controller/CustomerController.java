package com.CustomerService.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.CustomerService.CustomerRepository.CustomerRepository;
import com.CustomerService.Entity.Customer;
import com.CustomerService.Service.CustomerService;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {
    @Autowired private RestTemplate restTemplate;
    public CustomerRepository customerRepository;
    public CustomerService customerService;
    
    @PostMapping("/register")
    public Customer registerCustomer(@RequestBody Customer customer) {
        return customerRepository.save(customer);
    }

    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id) {
        return customerRepository.findById(id).orElse(null);
    }

    @PostMapping("/userSignUp")
    public ResponseEntity<String> signUpUser(@RequestBody Customer signUpRequest)
    {
        String name = signUpRequest.getCustomerName();
        String email = signUpRequest.getCustomerEmail();
        if( name == null || email == null)
        {
            return ResponseEntity.badRequest().body("Name and email are required fields");
        }
        
        Customer newCustomer = new Customer();
        newCustomer.setCustomerName(signUpRequest.getCustomerName());
        newCustomer.setCustomerEmail(signUpRequest.getCustomerEmail());
       
        Customer saveCustomer = customerService.createCustomer(newCustomer);
        customerRepository.save(saveCustomer);
        
        String notificationServiceURL = "http://localhost:8085/notification/sendNotification";
        String response = restTemplate.getForObject(notificationServiceURL, String.class);
        
        System.out.println("Customer: Message sent to Notification. Response from notification: "+ response);

        return ResponseEntity.ok("User signed up successfully!");
    }
}
