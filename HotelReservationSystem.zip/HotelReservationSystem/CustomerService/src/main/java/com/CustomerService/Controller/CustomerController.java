package com.CustomerService.Controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.CustomerService.CustomerRepository.CustomerRepository;
import com.CustomerService.Entity.Customer;
import com.CustomerService.Service.CustomerService;
import com.NotificationService.Service.NotificationService;

import jakarta.validation.constraints.Null;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {
    public CustomerRepository customerRepository;
    public CustomerService customerService;
    public NotificationService notificationService;

    @PostMapping("/register")
    public Customer registerCustomer(@RequestBody Customer customer) {
        return customerRepository.save(customer);
    }

    @GetMapping("/{id}")
    public Customer getCustomerById(@PathVariable Long id) {
        return customerRepository.findById(id).orElse(null);
    }

    @PostMapping("/userSignUp")
    public ResponseEntity<String> signUpUser(@RequestBody Customer signUpRequest)
    {
        String name = signUpRequest.getCustomerName();
        String email = signUpRequest.getCustomerEmail();
        if( name == null || email == null)
        {
            return ResponseEntity.badRequest().body("Name and email are required fields");
        }
        
        Customer newCustomer = new Customer();
        newCustomer.setCustomerName(signUpRequest.getCustomerName());
        newCustomer.setCustomerEmail(signUpRequest.getCustomerEmail());
       
        Customer saveCustomer = customerService.createCustomer(newCustomer);

        notificationService.sendWelcomeEmail(savedCustomer);
        return ResponseEntity.ok("User signed up successfully!");
    }
}
