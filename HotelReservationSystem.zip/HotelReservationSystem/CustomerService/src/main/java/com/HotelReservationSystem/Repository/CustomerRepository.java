package com.HotelReservationSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.HotelReservationSystem.Entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    void deleteById(Long id);} 
