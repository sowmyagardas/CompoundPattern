package com.HotelReservationSystem.CustomerService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.HotelReservationSystem.Entity.Customer;
import com.HotelReservationSystem.Entity.Notification;
import com.HotelReservationSystem.Entity.RoomInventory;
import com.HotelReservationSystem.Repository.CustomerRepository;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@Service
public class CustomerService {
    @Autowired
	private CustomerRepository customerRepository;
	@Autowired
	private KafkaTemplate<String, Notification> kafkaTemplate;
	private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);
	

	public ResponseEntity<?> updateCustomer(Customer customer) {
		Optional<Customer> customerFound = customerRepository.findById(customer.getId());
		if (customerFound.isPresent()) {
			customerRepository.save(customer);		
			// Send event to notification service to send notification
			Notification notification = new Notification();
			notification.setMessage("Customer details updated successfully!");
			kafkaTemplate.send("sendNotification", notification);			
			return ResponseEntity.ok("Customer details updated!");
		}
		return ResponseEntity.ok("Customer not found");
	}

	@CircuitBreaker(name = "HotelManagementService", fallbackMethod = "getDefaultHotelListing")
	public List<RoomInventory> getHotelListing(Boolean triggerFallback) {
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders(null);
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<List> entity = new HttpEntity<>(null, headers);
		ResponseEntity<List> response =null;
		//HotelManagement running on port 8083
		//To trigger circuit break 8085 port applied
		if(triggerFallback) {
		    response = restTemplate.exchange(("http://localhost:8085/hotelmanagement"), HttpMethod.GET, entity,
				List.class);
		}else {
			response = restTemplate.exchange(("http://localhost:8083/hotelmanagement"), HttpMethod.GET, entity,
					List.class);
		}
		List<RoomInventory> hotelList = response.getBody();
		if (hotelList != null) {
			return hotelList;
		}

		return new ArrayList<RoomInventory>();
	}

	public List<RoomInventory> getDefaultHotelListing(Boolean triggerFallback,Throwable e) {
		RoomInventory hotel=new RoomInventory();
		logger.info("Sorry Hotel details Unavailable Currently. Please try again later!!!");
		List<RoomInventory> hotelList=new ArrayList<RoomInventory>();
		hotelList.add(hotel);
		return hotelList;
	}


    public void saveCustomer(Customer customer) {
		customerRepository.save(customer);
		logger.info("Customer details saved successfully!");
	}
    
   	public ResponseEntity<?> deleteCustomer(Long customerId){
        customerRepository.deleteById(customerId);
        return ResponseEntity.ok("Deleted customer! ");
    }
	
}

