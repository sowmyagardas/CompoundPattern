package com.HotelReservationSystem.NotificationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.HotelReservationSystem.Entity.Notification;
import com.HotelReservationSystem.Repository.NotificationRepository;

@Service
public class NotificationService {
    @Autowired
	private NotificationRepository notificationRepository;

    public ResponseEntity<?> saveNotification(Notification notification) {
        notificationRepository.save(notification);
        return ResponseEntity.ok(notification.getMessage());
    }
}
