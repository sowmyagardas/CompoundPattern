package com.NotificationService.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Notification {
        @Id
        private Long id;
        private String message;
        private Long customerId;
}
