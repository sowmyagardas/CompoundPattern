package com.NotificationService.Service;

import com.NotificationService.Repository.NotificationRepository;

import javax.management.Notification;

import com.CustomerService.Entity.Customer;

public class NotificationService {
    public NotificationRepository notificationRepository;

    public void sendWelcomeEmail(Customer customer)
    {
        Notification welcomeNotification = new Notification(null, welcomeNotification, 0);
        welcomeNotification.setMessage("Welcome to our platform, " + customer.getName() + "!");
        welcomeNotification.setCustomerId(customer.getId());
        notificationRepository.save(welcomeNotification);
    }
}
